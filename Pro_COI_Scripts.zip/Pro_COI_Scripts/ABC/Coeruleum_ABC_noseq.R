## we selected the best method for P. coeruleum
## the method was: 
## rejection
##c("D", "H", "piC", "piI", "piC_I")
## tol=0.001
## now, it's time to perform the actual ABC analysis
## we'll also to abc for parameter estimates and save this posterior distribution to use in our posterior predictive simulations

## first, read in the prior and the observed data, and format the data for the analysis
library(abc)

## Set the working directory
setwd('/Users/msmith/Pro_COI_Revisions/ABC/Coeruleum/ABC_2pop_nobw')

## read in the prior
params_ss <- read.table(file="../ModelFit_2pop_nobw/coeruleum_difpops_noseq_prior.txt",sep="\t")

## change the variable names
names(params_ss) <- c("Model","ThetaAncestral", "DivergenceTime_AV", "MigrationRate","MigrationRate_Inland", "MigrationRate_Coast", "myseed","Scale_Param", "InlandProp", "CoastalProp", "pi", "ss", "D", "thetaH", "H", "piI",  "piC",  "piC_I")
head(params_ss)

## store the model as a factor, and pull out a vector of these indices
params_ss$Model <- as.factor(params_ss$Model)
summary(params_ss$Model)
index <- as.vector(params_ss$Model)

## define the tolerance and method to be used.
tol <- c(0.001)
method <- c("rejection")

## select the summary statistics and create a dataframe with just these stats
touse <- c("D", "H", "piC", "piI", "piC_I")
sumstat <- params_ss[,touse]

## get the observed data
observed_ss <- data.frame(0.09500*574,180,0.2326618,18.6198,0.6389305,0.09819*574,0,55.077)
names(observed_ss)<- c("pi", "ss", "D", "thetaH", "H", "piC",  "piI",  "piC_I")
head(observed_ss)
## select the appropriate sumstats
observed_target <- observed_ss[,touse]

## now, we're ready to conduct the ABC analysis
abcresults <- postpr(observed_target,index,sumstat, tol, method=method)
summary(abcresults)


