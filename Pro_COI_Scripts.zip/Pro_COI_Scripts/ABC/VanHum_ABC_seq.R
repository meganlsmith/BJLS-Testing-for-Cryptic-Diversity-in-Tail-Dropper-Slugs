## we selected the best method for P. vanhum
## the method was: 
## rejection
## c("pi", "piwiI", "piwiC", "nucdivbtC_I", "theta")
## tol=0.001
## now, it's time to perform the actual ABC analysis
## we'll also to abc for parameter estimates and save this posterior distribution to use in our posterior predictive simulations

## first, read in the prior and the observed data, and format the data for the analysis
library(abc)

## Set the working directory
setwd('/Users/msmith/Pro_COI_Revisions/ABC/VanHum/ABC_2pop_nobw')

## read in the prior
params_ss <- read.table(file="../ModelFit_2pop_nobw/vanhum_difpops_prior.txt",sep="\t")

## change the variable names
names(params_ss)<- c("Model","ThetaAncestral", "DivergenceTime", "MigrationRate", "MigrationRate_Inland", "MigrationRate_Coastal", "myseed","Scale_Param", "freqA", "freqC", "freqG", "freqT", "titv", "invsites", "gammacat", "shape", "InlandProp","CoastalProp","pi","S","piwiI","piwiC","nucdivbtC_I","theta")
head(params_ss)

## store the model as a factor, and pull out a vector of these indices
params_ss$Model <- as.factor(params_ss$Model)
summary(params_ss$Model)
index <- as.vector(params_ss$Model)

## define the tolerance and method to be used.
tol <- c(0.001)
method <- c("rejection")

## select the summary statistics and create a dataframe with just these stats
touse <-c("pi", "piwiI", "piwiC", "nucdivbtC_I", "theta")
sumstat <- params_ss[,touse]

## get the observed data
observed_ss <- read.table(file="../Sumstats_Obs/p_vanhum_2pops_nobw_sumstats_seq.txt",sep="\t",header=F)
names(observed_ss)<- c("pi","S","piwiC","piwiI","nucdivbtC_I","theta")
head(observed_ss)
## select the appropriate sumstats
observed_target <- observed_ss[,touse]

## now, we're ready to conduct the ABC analysis
abcresults <- postpr(observed_target,index,sumstat, tol, method=method)
summary(abcresults)


