## This script performs a cross validation for step 1 for Prophysaon coeruleum

## first, read in the prior and the observed data, and format the data for the $
library("quantreg", lib.loc="~/local/R_libs/")
library("abc", lib.loc="~/local/R_libs/")
## Set the working directory
setwd('/fs/project/PAS1181/Pro_COI_August2017/ABC_November/Crossval_revisions_oldmods/Coeruleum')
#setwd('/Users/msmith/Pro_COI_Revisions/ABC/Coeruleum/CrossVal_2pops_nobw')
## read in the prior

params_ss <- read.table(file="coeruleum_difpops_prior.txt",sep="\t")
names(params_ss)<- c("Model","ThetaAncestral", "DivergenceTime", "MigrationRate", "MigrationRate_Inland", "MigrationRate_Coastal", "myseed","Scale_Param", "freqA", "freqC", "freqG", "freqT", "titv", "invsites", "gammacat", "shape", "InlandProp","CoastalProp","pi","S","piwiI","piwiC","nucdivbtC_I","theta")
head(params_ss)
params_ss$Model <- as.factor(params_ss$Model)
summary(params_ss$Model)

## make sumstats vectors
vec1 <- c("pi","S","piwiI","piwiC","nucdivbtC_I","theta")
combos_1<- combn(vec1, m=1,simplyify=F)
combos_2<- combn(vec1, m=2,simplyify=F)
combos_3<- combn(vec1, m=3,simplyify=F)
combos_4<- combn(vec1, m=4,simplyify=F)
combos_5<- combn(vec1, m=5,simplyify=F)
combos_6<- combn(vec1, m=6,simplyify=F)
all_combos <- list(combos_1,combos_2,combos_3,combos_4,combos_5,combos_6)
length(all_combos)
## organize prior
index <- as.vector(params_ss$Model)
tol <- c(0.001,0.005,0.01,0.05)
mymethods <- c("rejection")
mycrossval <- data.frame(M1 = numeric(), M2 = numeric(), M3 = numeric(), tol = character(), sumstats = character(),method= character())
## loop through all of the combinations of sumstats and methods, and perform a cross-validation analysis using 10 replicates.
for (k in 1:1){ #for all methods
  methody = mymethods[k] #set method y equal to the method
  for (i in 1:length(all_combos)){ #for all combos
    for (j in 1:dim(all_combos[[i]])[2]){
      tryCatch({ # set up exception in case of an error due to too little variance in the selected region
        touse <- c(all_combos[[i]][,j]) # create a list of the sumstats to use
        sumstat <- params_ss[,touse] # create a dataframe with only those columns
        nval=10 # set the number of replicates to 10
        crossval <- cv4postpr(index,sumstat,method=methody,nval = nval, tols = tol) # perform the crossval
        tol_0.001 <- crossval$model.probs$tol0.001 # pull out parts of the results corresponding to tol=0.001
        models <- rownames(tol_0.001) # note the models
        tol_0.001<- data.frame(cbind(tol_0.001, models), row.names=NULL) # make a dataframe of models and post prob
        m1 <- subset(tol_0.001, models==1) # split the dataframe for the models
        m2 <- subset(tol_0.001, models==2)
        m3 <- subset(tol_0.001, models==3)
        m1 <- sum(as.numeric(as.character(m1$X1)))/nrow(m1) # calculate mean posterior probability of correct model under each model
        m2 <- sum(as.numeric(as.character(m2$X2)))/nrow(m2)
        m3 <- sum(as.numeric(as.character(m3$X3)))/nrow(m3)
        summies = paste(touse, collapse=',') # create string listing sumstats used
        newadd <- data.frame(M1 = m1, M2 = m2, M3 = m3, tol = 'tol_0.001',sumstats=summies, method=methody) # make a dataframe with the mean post probs, the tolerance, the sumstats, and the methods
        mycrossval<- rbind(mycrossval,newadd) # append this to the growing dataframe
        tol_0.005 <- crossval$model.probs$tol0.005 # do the same for the three other tolerances
        models <- rownames(tol_0.005)
        tol_0.005<- data.frame(cbind(tol_0.005, models), row.names=NULL)
        m1 <- subset(tol_0.005, models==1)
        m2 <- subset(tol_0.005, models==2)
        m3 <- subset(tol_0.005, models==3)
        m1 <- sum(as.numeric(as.character(m1$X1)))/nrow(m1)
        m2 <- sum(as.numeric(as.character(m2$X2)))/nrow(m2)
        m3 <- sum(as.numeric(as.character(m3$X3)))/nrow(m3)
        summies = paste(touse, collapse=',')
        newadd <- data.frame(M1 = m1, M2 = m2, M3 = m3, tol = 'tol_0.005',sumstats=summies, method=methody)
        mycrossval<- rbind(mycrossval,newadd)    
        tol_0.01 <- crossval$model.probs$tol0.01
        models <- rownames(tol_0.01)
        tol_0.01<- data.frame(cbind(tol_0.01, models), row.names=NULL)
        m1 <- subset(tol_0.01, models==1)
        m2 <- subset(tol_0.01, models==2)
        m3 <- subset(tol_0.01, models==3)
        m1 <- sum(as.numeric(as.character(m1$X1)))/nrow(m1)
        m2 <- sum(as.numeric(as.character(m2$X2)))/nrow(m2)
        m3 <- sum(as.numeric(as.character(m3$X3)))/nrow(m3)
        summies = paste(touse, collapse=',')
        newadd <- data.frame(M1 = m1, M2 = m2, M3 = m3, tol = 'tol_0.01',sumstats=summies, method=methody)
        mycrossval<- rbind(mycrossval,newadd)
        tol_0.05 <- crossval$model.probs$tol0.05
        models <- rownames(tol_0.05)
        tol_0.05<- data.frame(cbind(tol_0.05, models), row.names=NULL)
        m1 <- subset(tol_0.05, models==1)
        m2 <- subset(tol_0.05, models==2)
        m3 <- subset(tol_0.05, models==3)
        m1 <- sum(as.numeric(as.character(m1$X1)))/nrow(m1)
        m2 <- sum(as.numeric(as.character(m2$X2)))/nrow(m2)
        m3 <- sum(as.numeric(as.character(m3$X3)))/nrow(m3)
        summies = paste(touse, collapse=',')
        newadd <- data.frame(M1 = m1, M2 = m2, M3 = m3, tol = 'tol_0.05',sumstats=summies, method=methody)
        mycrossval<- rbind(mycrossval,newadd)
      }, error=function(e){cat("ERROR:",conditionMessage(e), "\n")}) # exception
    }
  }
}
write.csv(mycrossval,file="Crossval_coeruleum.csv", row.names=F) # write results to a csv file
