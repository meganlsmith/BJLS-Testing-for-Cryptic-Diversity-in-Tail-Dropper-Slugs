## This script performs a cross validation for step 1 for Prophysaon dubium

## first, read in the prior and the observed data, and format the data for the $
library("quantreg", lib.loc="~/local/R_libs/")
library("abc", lib.loc="~/local/R_libs/")
## Set the working directory
setwd('/fs/project/PAS1181/Pro_COI_August2017/ABC_November/Crossval_revisions_oldmods/Dubium')
#setwd('/Users/msmith/Pro_COI_Revisions/ABC/Dubium/CrossVal_2pops_nobw')
## read in the prior

params_ss <- read.table(file="dubium_difpops_noseq_s2_prior.txt",sep="\t")
names(params_ss) <- c("Model","ThetaAncestral", "DivergenceTime_AV", "MigrationRate","MigrationRate_Inland", "MigrationRate_Coast", "myseed","Scale_Param", "InlandProp", "CoastalProp", "pi", "ss", "D", "thetaH", "H", "piI",  "piC",  "piC_I")
head(params_ss)
params_ss$Model <- as.factor(params_ss$Model)
summary(params_ss$Model)

## make sumstats vectors
vec1 <- c("pi", "ss", "D", "thetaH", "H", "piC",  "piI",  "piC_I")
combos_1<- combn(vec1, m=1,simplyify=F)
combos_2<- combn(vec1, m=2,simplyify=F)
combos_3<- combn(vec1, m=3,simplyify=F)
combos_4<- combn(vec1, m=4,simplyify=F)
combos_5<- combn(vec1, m=5,simplyify=F)
combos_6<- combn(vec1, m=6,simplyify=F)
combos_7<- combn(vec1, m=7,simplyify=F)
combos_8<- combn(vec1, m=8,simplyify=F)
all_combos <- list(combos_1,combos_2,combos_3,combos_4,combos_5,combos_6,combos_7,combos_8)
length(all_combos)
## organize prior
index <- as.vector(params_ss$Model)
tol <- c(0.001,0.005,0.01,0.05)
mymethods <- c("rejection")
mycrossval <- data.frame(M1 = numeric(), M4 = numeric(), tol = character(), sumstats = character(),method= character())
## loop through all of the combinations of sumstats and methods, and perform a cross-validation analysis using 10 replicates.
for (k in 1:1){ #for all methods
  methody = mymethods[k] #set method y equal to the method
  for (i in 1:length(all_combos)){ #for all combos
    for (j in 1:dim(all_combos[[i]])[2]){
      tryCatch({ # set up exception in case of an error due to too little variance in the selected region
        touse <- c(all_combos[[i]][,j]) # create a list of the sumstats to use
        sumstat <- params_ss[,touse] # create a dataframe with only those columns
        nval=10 # set the number of replicates to 10
        crossval <- cv4postpr(index,sumstat,method=methody,nval = nval, tols = tol) # perform the crossval
        tol_0.001 <- crossval$model.probs$tol0.001 # pull out parts of the results corresponding to tol=0.001
        models <- rownames(tol_0.001) # note the models
        tol_0.001<- data.frame(cbind(tol_0.001, models), row.names=NULL) # make a dataframe of models and post prob
        m1 <- subset(tol_0.001, models==1) # split the dataframe for the models
        m4 <- subset(tol_0.001, models==4)
        m1 <- sum(as.numeric(as.character(m1$X1)))/nrow(m1) # calculate mean posterior probability of correct model under each model
        m4 <- sum(as.numeric(as.character(m4$X4)))/nrow(m4)
        summies = paste(touse, collapse=',') # create string listing sumstats used
        newadd <- data.frame(M1 = m1, M4 = m4, tol = 'tol_0.001',sumstats=summies, method=methody) # make a dataframe with the mean post probs, the tolerance, the sumstats, and the methods
        mycrossval<- rbind(mycrossval,newadd) # append this to the growing dataframe
        tol_0.005 <- crossval$model.probs$tol0.005 # do the same for the three other tolerances
        models <- rownames(tol_0.005)
        tol_0.005<- data.frame(cbind(tol_0.005, models), row.names=NULL)
        m1 <- subset(tol_0.005, models==1)
        m4 <- subset(tol_0.005, models==4)
        m1 <- sum(as.numeric(as.character(m1$X1)))/nrow(m1)
        m4 <- sum(as.numeric(as.character(m4$X4)))/nrow(m4)
        summies = paste(touse, collapse=',')
        newadd <- data.frame(M1 = m1, M4 = m4, tol = 'tol_0.005',sumstats=summies, method=methody)
        mycrossval<- rbind(mycrossval,newadd)    
        tol_0.01 <- crossval$model.probs$tol0.01
        models <- rownames(tol_0.01)
        tol_0.01<- data.frame(cbind(tol_0.01, models), row.names=NULL)
        m1 <- subset(tol_0.01, models==1)
        m4 <- subset(tol_0.01, models==4)
        m1 <- sum(as.numeric(as.character(m1$X1)))/nrow(m1)
        m4 <- sum(as.numeric(as.character(m4$X4)))/nrow(m4)
        summies = paste(touse, collapse=',')
        newadd <- data.frame(M1 = m1, M4 = m4, tol = 'tol_0.01',sumstats=summies, method=methody)
        mycrossval<- rbind(mycrossval,newadd)
        tol_0.05 <- crossval$model.probs$tol0.05
        models <- rownames(tol_0.05)
        tol_0.05<- data.frame(cbind(tol_0.05, models), row.names=NULL)
        m1 <- subset(tol_0.05, models==1)
        m4 <- subset(tol_0.05, models==4)
        m1 <- sum(as.numeric(as.character(m1$X1)))/nrow(m1)
        m4 <- sum(as.numeric(as.character(m4$X4)))/nrow(m4)
        summies = paste(touse, collapse=',')
        newadd <- data.frame(M1 = m1, M4 = m4, tol = 'tol_0.05',sumstats=summies, method=methody)
        mycrossval<- rbind(mycrossval,newadd)
      }, error=function(e){cat("ERROR:",conditionMessage(e), "\n")}) # exception
    }
  }
}
write.csv(mycrossval,file="Crossval_dubium_noseq_s2.csv", row.names=F) # write results to a csv file
