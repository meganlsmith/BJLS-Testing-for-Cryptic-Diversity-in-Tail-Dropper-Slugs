## This script is for completing the cross-validation for the recent dispersal models without nosequence data
setwd("/Users/msmith/Pro_COI_Revisions/ABC/Dubium/Crossval_2pops_nobw/")
## Read in the crossval file
mycrossval<- read.csv('Crossval_dubium_noseq_short.csv')
head(mycrossval) ## should have six columns

## you'll need to change the threshold. We want 3-4 models to compare further.
myhigher <- subset(mycrossval,  M1>0.45 & M2>0.45 & M3>0.45  & method == 'rejection') 
nrow(myhigher) # count these records
write.csv(myhigher,file="MyBestMethods_dubium_noseq.csv") #write this output to a csv
myhigher #look at the output, and note in your spreadsheet

## now we'll run more replicates with these models
library(abc)

## read in the prior
params_ss <- read.table(file="../ModelFit_2pop_nobw/dubium_difpops_noseq_prior.txt",sep="\t")
names(params_ss) <- c("Model","ThetaAncestral", "DivergenceTime_AV", "MigrationRate","MigrationRate_Inland", "MigrationRate_Coast", "myseed","Scale_Param", "InlandProp", "CoastalProp", "pi", "ss", "D", "thetaH", "H", "piI",  "piC",  "piC_I")
head(params_ss)
params_ss$Model <- as.factor(params_ss$Model)
summary(params_ss$Model)

## edit these my hand to match 'myhigher'
## best methods 1
index <- as.vector(params_ss$Model)
tol <- 0.001
mymethods <- myhigher[1,6]
mycrossval_met1 <- data.frame(M1 = numeric(), M2 = numeric(), M3 = numeric(), tol = character(), sumstats = character(),method= character())
touse <- toString(myhigher[1,5])
touse <- strsplit(touse, ",")
sumstat <- params_ss[,touse[[1]]]
nval=100
crossval <- cv4postpr(index,sumstat,method=mymethods,nval = nval, tols = tol)
tol_0.001 <- crossval$model.probs$tol0.001
models <- rownames(tol_0.001)
tol_0.001<- data.frame(cbind(tol_0.001, models), row.names=NULL)
m1 <- subset(tol_0.001, models==1)
m2 <- subset(tol_0.001, models==2)
m3 <- subset(tol_0.001, models==3)
m1 <- sum(as.numeric(as.character(m1$X1)))/nrow(m1)
m2 <- sum(as.numeric(as.character(m2$X2)))/nrow(m2)
m3 <- sum(as.numeric(as.character(m3$X3)))/nrow(m3)
summies = paste(touse, collapse=',')
newadd <- data.frame(M1 = m1, M2 = m2, M3 = m3, tol = 'tol_0.001',sumstats=summies, method=mymethods)
mycrossval_met1<- rbind(mycrossval_met1,newadd)


## best methods 2
index <- as.vector(params_ss$Model)
tol <- 0.001
mymethods <- myhigher[2,6]
mycrossval2_met2 <- data.frame(M1 = numeric(), M2 = numeric(), M3 = numeric(), tol = character(), sumstats = character(),method= character())
touse <- toString(myhigher[2,5])
touse <- strsplit(touse, ",")
sumstat <- params_ss[,touse[[1]]]
nval=100
crossval2 <- cv4postpr(index,sumstat,method=mymethods,nval = nval, tols = tol)
tol_0.001 <- crossval2$model.probs$tol0.001
models <- rownames(tol_0.001)
tol_0.001<- data.frame(cbind(tol_0.001, models), row.names=NULL)
m1 <- subset(tol_0.001, models==1)
m2 <- subset(tol_0.001, models==2)
m3 <- subset(tol_0.001, models==3)
m1 <- sum(as.numeric(as.character(m1$X1)))/nrow(m1)
m2 <- sum(as.numeric(as.character(m2$X2)))/nrow(m2)
m3 <- sum(as.numeric(as.character(m3$X3)))/nrow(m3)
summies = paste(touse, collapse=',')
newadd <- data.frame(M1 = m1, M2 = m2, M3 = m3, tol = 'tol_0.001',sumstats=summies, method=mymethods)
mycrossval2_met2<- rbind(mycrossval2_met2,newadd)

## best methods 3
index <- as.vector(params_ss$Model)
tol <- 0.001
mymethods <- myhigher[3,6]
mycrossval3_met3 <- data.frame(M1 = numeric(), M2 = numeric(), M3 = numeric(), tol = character(), sumstats = character(),method= character())
touse <- toString(myhigher[3,5])
touse <- strsplit(touse, ",")
sumstat <- params_ss[,touse[[1]]]
nval=100
crossval3 <- cv4postpr(index,sumstat,method=mymethods,nval = nval, tols = tol)
tol_0.001 <- crossval3$model.probs$tol0.001
models <- rownames(tol_0.001)
tol_0.001<- data.frame(cbind(tol_0.001, models), row.names=NULL)
m1 <- subset(tol_0.001, models==1)
m2 <- subset(tol_0.001, models==2)
m3 <- subset(tol_0.001, models==3)
m1 <- sum(as.numeric(as.character(m1$X1)))/nrow(m1)
m2 <- sum(as.numeric(as.character(m2$X2)))/nrow(m2)
m3 <- sum(as.numeric(as.character(m3$X3)))/nrow(m3)
summies = paste(touse, collapse=',')
newadd <- data.frame(M1 = m1, M2 = m2, M3 = m3, tol = 'tol_0.001',sumstats=summies, method=mymethods)
mycrossval3_met3<- rbind(mycrossval3_met3,newadd)


thebestmods <- rbind(mycrossval_met1, mycrossval2_met2, mycrossval3_met3) # combine the results from this last part
thebestmods$sumofprob <- thebestmods$M1+thebestmods$M2+thebestmods$M3 # calculate the sum of the posterior probs
write.csv(thebestmods, file="BestMods_N100_Dubium_pt2_noseq.csv",row.names=F) # write these results to a file.

## don't forget to keep plots, etc for the best method after you complete this step.You may have to rerun to do this.
summary(crossval3)
pdf("Summary_Dubium_CVABC_pt2_noseq.pdf")
plot(crossval3)
dev.off()
