library(dplyr)
## This script is for completing the cross-validation for the recent dispersal models without nosequence data
setwd("/Users/msmith/Pro_COI_Revisions/ABC/VanHum/Crossval_2pop_nobw/")
## Read in the crossval file
mycrossval<- read.csv('Crossval_vanhum_noseq_S2.csv')
head(mycrossval) ## should have six columns

## you'll need to change the threshold. We want 3-4 models to compare further.
myhigher <- subset(mycrossval,  M3>0.9995 & M4>0.9995 & method == 'rejection') 
nrow(myhigher) # count these records
myhigher <- sample_n(myhigher, 3)

write.csv(myhigher,file="MyBestMethods_vanhum_noseq_S2.csv") #write this output to a csv
myhigher #look at the output, and note in your spreadsheet

## now we'll run more replicates with these models
library(abc)

## read in the prior
params_ss <- read.table(file="../ModelFit_2pop_nobw/vanhum_difpops_noseq_s2_prior.txt",sep="\t")
names(params_ss) <- c("Model","ThetaAncestral", "DivergenceTime_AV", "MigrationRate","MigrationRate_Inland", "MigrationRate_Coast", "myseed","Scale_Param", "InlandProp", "CoastalProp", "pi", "ss", "D", "thetaH", "H", "piI",  "piC",  "piC_I")
head(params_ss)
params_ss$Model <- as.factor(params_ss$Model)
summary(params_ss$Model)

## edit these my hand to match 'myhigher'
## best methods 1
index <- as.vector(params_ss$Model)
tol <- 0.001
mymethods <- myhigher[1,5]
mycrossval_met1 <- data.frame(M3 = numeric(), M4 = numeric(), tol = character(), sumstats = character(),method= character())
touse <- toString(myhigher[1,4])
touse <- strsplit(touse, ",")
sumstat <- params_ss[,touse[[1]]]
nval=100
crossval <- cv4postpr(index,sumstat,method=mymethods,nval = nval, tols = tol)
tol_0.001 <- crossval$model.probs$tol0.001
models <- rownames(tol_0.001)
tol_0.001<- data.frame(cbind(tol_0.001, models), row.names=NULL)
m3 <- subset(tol_0.001, models==3)
m4 <- subset(tol_0.001, models==4)
m3 <- sum(as.numeric(as.character(m3$X3)))/nrow(m3)
m4 <- sum(as.numeric(as.character(m4$X4)))/nrow(m4)
summies = paste(touse, collapse=',')
newadd <- data.frame(M3 = m3, M4 = m4, tol = 'tol_0.001',sumstats=summies, method=mymethods)
mycrossval_met1<- rbind(mycrossval_met1,newadd)


## best methods 2
index <- as.vector(params_ss$Model)
tol <- c(0.001)
mymethods <- myhigher[2,5]
mycrossval2_met2 <- data.frame(M3 = numeric(),  M4 = numeric(), tol = character(), sumstats = character(),method= character())
touse <- toString(myhigher[2,4])
touse <- strsplit(touse, ",")
sumstat <- params_ss[,touse[[1]]]
nval=100
crossval2 <- cv4postpr(index,sumstat,method=mymethods,nval = nval, tols = tol)
tol_0.001 <- crossval2$model.probs$tol0.001
models <- rownames(tol_0.001)
tol_0.001<- data.frame(cbind(tol_0.001, models), row.names=NULL)
m3 <- subset(tol_0.001, models==3)
m4 <- subset(tol_0.001, models==4)
m3 <- sum(as.numeric(as.character(m3$X3)))/nrow(m3)
m4 <- sum(as.numeric(as.character(m4$X4)))/nrow(m4)
summies = paste(touse, collapse=',')
newadd <- data.frame(M3 = m3, M4 = m4, tol = 'tol_0.001',sumstats=summies, method=mymethods)
mycrossval2_met2<- rbind(mycrossval2_met2,newadd)


## best methods 3
index <- as.vector(params_ss$Model)
tol <- c(0.001)
mymethods <- myhigher[3,5]
mycrossval3_met3 <- data.frame(M3 = numeric(),  M4 = numeric(), tol = character(), sumstats = character(),method= character())
touse <- toString(myhigher[3,4])
touse <- strsplit(touse, ",")
sumstat <- params_ss[,touse[[1]]]
nval=100
crossval3 <- cv4postpr(index,sumstat,method=mymethods,nval = nval, tols = tol)
tol_0.001 <- crossval3$model.probs$tol0.001
models <- rownames(tol_0.001)
tol_0.001<- data.frame(cbind(tol_0.001, models), row.names=NULL)
m3 <- subset(tol_0.001, models==3)
m4 <- subset(tol_0.001, models==4)
m3 <- sum(as.numeric(as.character(m3$X3)))/nrow(m3)
m4 <- sum(as.numeric(as.character(m4$X4)))/nrow(m4)
summies = paste(touse, collapse=',')
newadd <- data.frame(M3 = m3, M4 = m4, tol = 'tol_0.001',sumstats=summies, method=mymethods)
mycrossval3_met3<- rbind(mycrossval3_met3,newadd)



thebestmods <- rbind(mycrossval_met1, mycrossval2_met2, mycrossval3_met3) # combine the results from this last part
thebestmods$sumofprob <- thebestmods$M3+thebestmods$M4 # calculate the sum of the posterior probs
write.csv(thebestmods, file="BestMods_N100_VanHum_pt2_noseq_s2.csv",row.names=F) # write these results to a file.

## don't forget to keep plots, etc for the best method after you complete this step.You may have to rerun to do this.
summary(crossval)
pdf("Summary_VanHum_CVABC_pt2_noseq_s2.pdf")
plot(crossval)
dev.off()
