
## first, read in the prior and the observed data, and format the data for the analysis
library(abc)

## Set the working directory
setwd('/Users/msmith/Pro_COI_Revisions/ABC/Andersoni/ModelFit_2pop_nobw/')

## read in the prior
prior_andersoni <- read.table(file="andersoni_difpops_noseq_prior.txt",sep="\t")

## change the variable names
names(prior_andersoni) <- c("Model","ThetaAncestral", "DivergenceTime_AV", "MigrationRate","MigrationRate_Inland", "MigrationRate_Coast", "myseed","Scale_Param", "InlandProp", "CoastalProp", "pi", "ss", "D", "thetaH", "H", "piI",  "piC",  "piC_I")
head(prior_andersoni)

## store the model as a factor, and pull out a vector of these indices
prior_andersoni$Model <- as.factor(prior_andersoni$Model)
summary(prior_andersoni$Model)
index <- as.vector(prior_andersoni$Model)

## get the observed data
observed_ss <- data.frame(0.04751*574, 144, -0.4523532, 9.995557, 0.7722038, 0.05091*574, 0.00824*574, 23.222)
names(observed_ss)<- c("pi", "ss", "D", "thetaH", "H", "piC",  "piI",  "piC_I")
head(observed_ss)

## now, let's plot simulated and observed ss
pdf(file="andersoni_modelfit_noseq_pi.pdf")
hist(prior_andersoni$pi)
abline(v=observed_ss$pi, lwd=2, col="blue")
dev.off()
sum(prior_andersoni$pi>=observed_ss$pi)/length(prior_andersoni$pi)

pdf(file="andersoni_modelfit_noseq_ss.pdf")
hist(prior_andersoni$ss)
abline(v=observed_ss$ss, lwd=2, col="blue")
dev.off()
sum(prior_andersoni$ss>=observed_ss$ss)/length(prior_andersoni$ss)

pdf(file="andersoni_modelfit_noseq_D.pdf")
hist(prior_andersoni$D)
abline(v=observed_ss$D, lwd=2, col="blue")
dev.off()
sum(prior_andersoni$D>=observed_ss$D)/length(prior_andersoni$D)

pdf(file="andersoni_modelfit_noseq_thetaH.pdf")
hist(prior_andersoni$thetaH)
abline(v=observed_ss$thetaH, lwd=2, col="blue")
dev.off()
sum(prior_andersoni$thetaH>=observed_ss$thetaH)/length(prior_andersoni$thetaH)

pdf(file="andersoni_modelfit_noseq_H.pdf")
hist(prior_andersoni$H)
abline(v=observed_ss$H, lwd=2, col="blue")
dev.off()
sum(prior_andersoni$H<=observed_ss$H)/length(prior_andersoni$H)

pdf(file="andersoni_modelfit_noseq_piC.pdf")
hist(prior_andersoni$piC)
abline(v=observed_ss$piC, lwd=2, col="blue")
dev.off()
sum(prior_andersoni$piC>=observed_ss$piC)/length(prior_andersoni$piC)

pdf(file="andersoni_modelfit_noseq_piI.pdf")
hist(prior_andersoni$piI)
abline(v=observed_ss$piI, lwd=2, col="blue")
dev.off()
sum(prior_andersoni$piI<=observed_ss$piI)/length(prior_andersoni$piI)

pdf(file="andersoni_modelfit_noseq_piC_I.pdf")
hist(prior_andersoni$piC_I)
abline(v=observed_ss$piC_I, lwd=2, col="blue")
dev.off()
sum(prior_andersoni$piC_I>=observed_ss$piC_I)/length(prior_andersoni$piC_I)


#library(ggplot2)
#ggplot(prior_andersoni, aes(x=pi, fill=Model)) + geom_histogram(col='black') + geom_vline(xintercept=observed_ss$pi)
#ggplot(prior_andersoni, aes(x=ss, fill=Model)) + geom_histogram(col='black') + geom_vline(xintercept=observed_ss$ss)
#ggplot(prior_andersoni, aes(x=D, fill=Model)) + geom_histogram(col='black') + geom_vline(xintercept=observed_ss$D)
#ggplot(prior_andersoni, aes(x=thetaH, fill=Model)) + geom_histogram(col='black') + geom_vline(xintercept=observed_ss$thetaH)
#ggplot(prior_andersoni, aes(x=H, fill=Model)) + geom_histogram(col='black') + geom_vline(xintercept=observed_ss$H)
#ggplot(prior_andersoni, aes(x=piNC, fill=Model)) + geom_histogram(col='black') + geom_vline(xintercept=observed_ss$piNC)
#ggplot(prior_andersoni, aes(x=piSC, fill=Model)) + geom_histogram(col='black') + geom_vline(xintercept=observed_ss$piSC)
#ggplot(prior_andersoni, aes(x=piIN, fill=Model)) + geom_histogram(col='black') + geom_vline(xintercept=observed_ss$piIN)
#ggplot(prior_andersoni, aes(x=piNC_SC, fill=Model)) + geom_histogram(col='black') + geom_vline(xintercept=observed_ss$piNC_SC)
#ggplot(prior_andersoni, aes(x=piNC_IN, fill=Model)) + geom_histogram(col='black') + geom_vline(xintercept=observed_ss$piNC_IN)
#ggplot(prior_andersoni, aes(x=piSC_IN, fill=Model)) + geom_histogram(col='black') + geom_vline(xintercept=observed_ss$piSC_IN)


## Use parameter estimation to get an idea
tol <- c(0.01)
method <- c("rejection")

## select the summary statistics and create a dataframe with just these stats
touse <- c("pi", "ss", "D", "thetaH", "H", "piC",  "piI",  "piC_I")
sumstat <- prior_andersoni[,touse]
observed_target <- observed_ss[,touse]
abcresults <- postpr(observed_target,index,sumstat, tol, method=method)
summary(abcresults)

## param est
## estimate parameter values
partouse <- c("ThetaAncestral", "DivergenceTime_AV", "MigrationRate","MigrationRate_Inland", "MigrationRate_Coast", "myseed","Scale_Param", "InlandProp", "CoastalProp")
params <- prior_andersoni[,partouse]
params[is.na(params)] <- 0

abcparam <- abc(observed_target,params,sumstat, tol, method=method)
summary(abcparam)

## plot posterior param estimates
## get posterior parameter estimates and plot them
posterior <- as.data.frame(abcparam$unadj.values)

pdf(file="andersoni_posterior_ThetaAncestral_noseq.pdf")
plot(posterior$ThetaAncestral, ylim = c(0.01,20))
dev.off()

pdf(file="andersoni_posterior_DivergenceTime_AV_noseq.pdf")
plot(posterior$DivergenceTime_AV,ylim=c(0.1,30))
dev.off()

pdf(file="andersoni_posterior_MigrationRate_noseq.pdf")
plot(posterior$MigrationRate,ylim=c(0,10))
dev.off()

pdf(file="andersoni_posterior_MigrationRate_Inland_noseq.pdf")
plot(posterior$MigrationRate_Inland,ylim=c(0,10))
dev.off()

pdf(file="andersoni_posterior_MigrationRate_Coast_noseq.pdf")
plot(posterior$MigrationRate_Coast,ylim=c(0,10))
dev.off()

pdf(file="andersoni_posterior_InlandProp_noseq.pdf")
plot(posterior$InlandProp,ylim=c(0.1,2))
dev.off()

pdf(file="andersoni_posterior_CoastalProp_noseq.pdf")
plot(posterior$CoastalProp,ylim=c(0.1,2))
dev.off()

