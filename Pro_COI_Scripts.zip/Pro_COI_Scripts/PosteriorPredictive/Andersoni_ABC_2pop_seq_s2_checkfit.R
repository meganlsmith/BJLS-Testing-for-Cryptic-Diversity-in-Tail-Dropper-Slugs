
## first, read in the prior and the observed data, and format the data for the analysis
library(abc)

## Set the working directory
setwd('/Users/msmith/Pro_COI_Revisions/ABC/Andersoni/ModelFit_2pop_nobw/')

## read in the prior
prior_andersoni <- read.table(file="andersoni_difpops_s2_prior.txt",sep="\t")

## change the variable names
names(prior_andersoni)<- c("Model","ThetaAncestral", "DivergenceTime", "MigrationRate", "MigrationRate_Inland", "MigrationRate_Coastal", "myseed","Scale_Param", "freqA", "freqC", "freqG", "freqT", "titv", "invsites", "gammacat", "shape", "InlandProp","CoastalProp","pi","S","piwiI","piwiC","nucdivbtC_I","theta")

head(prior_andersoni)

## store the model as a factor, and pull out a vector of these indices
prior_andersoni$Model <- as.factor(prior_andersoni$Model)
summary(prior_andersoni$Model)
index <- as.vector(prior_andersoni$Model)

## get the observed data
observed_ss <- read.table(file="../Sumstats_Obs/P_and_2pop_nobw_sumstats_seq.txt",sep="\t",header=F)
names(observed_ss)<- c("pi","S","piwiC","piwiI","nucdivbtC_I","theta")
head(observed_ss)

## now, let's plot simulated and observed ss
pdf(file="andersoni_modelfit_seq_pi_s2.pdf")
hist(prior_andersoni$pi)
abline(v=observed_ss$pi, lwd=2, col="blue")
dev.off()
sum(prior_andersoni$pi<=observed_ss$pi)/length(prior_andersoni$pi)

pdf(file="andersoni_modelfit_seq_S_s2.pdf")
hist(prior_andersoni$S)
abline(v=observed_ss$S, lwd=2, col="blue")
dev.off()
sum(prior_andersoni$S<=observed_ss$S)/length(prior_andersoni$S)

pdf(file="andersoni_modelfit_seq_piwiC_s2.pdf")
hist(prior_andersoni$piwiC)
abline(v=observed_ss$piwiC, lwd=2, col="blue")
dev.off()
sum(prior_andersoni$piwiC<=observed_ss$piwiC)/length(prior_andersoni$piwiC)

pdf(file="andersoni_modelfit_seq_piwiI_s2.pdf")
hist(prior_andersoni$piwiI)
abline(v=observed_ss$piwiI, lwd=2, col="blue")
dev.off()
sum(prior_andersoni$piwiI<=observed_ss$piwiI)/length(prior_andersoni$piwiI)



pdf(file="andersoni_modelfit_seq_nucdivbtC_I_s2.pdf")
hist(prior_andersoni$nucdivbtC_I)
abline(v=observed_ss$nucdivbtC_I, lwd=2, col="blue")
dev.off()
sum(prior_andersoni$nucdivbtC_I<=observed_ss$nucdivbtC_I)/length(prior_andersoni$nucdivbtC_I)

pdf(file="andersoni_modelfit_seq_theta_s2.pdf")
hist(prior_andersoni$theta)
abline(v=observed_ss$theta, lwd=2, col="blue")
dev.off()
sum(prior_andersoni$theta<=observed_ss$theta)/length(prior_andersoni$theta)

#library(ggplot2)
#ggplot(prior_andersoni, aes(x=pi, fill=Model)) + geom_histogram(col='black', binwidth = 0.01) + geom_vline(xintercept=observed_ss$pi)
#ggplot(prior_andersoni, aes(x=S, fill=Model)) + geom_histogram(col='black') + geom_vline(xintercept=observed_ss$S)
#ggplot(prior_andersoni, aes(x=piwiNC, fill=Model)) + geom_histogram(col='black') + geom_vline(xintercept=observed_ss$piwiNC)
#ggplot(prior_andersoni, aes(x=piwiSC, fill=Model)) + geom_histogram(col='black') + geom_vline(xintercept=observed_ss$piwiSC)
#ggplot(prior_andersoni, aes(x=piwiIN, fill=Model)) + geom_histogram(col='black') + geom_vline(xintercept=observed_ss$piwiIN)
#ggplot(prior_andersoni, aes(x=nucdivbtNC_SC, fill=Model)) + geom_histogram(col='black') + geom_vline(xintercept=observed_ss$nucdivbtNC_SC)
#ggplot(prior_andersoni, aes(x=nucdivbtNC_IN, fill=Model)) + geom_histogram(col='black') + geom_vline(xintercept=observed_ss$nucdivbtNC_IN)
#ggplot(prior_andersoni, aes(x=nucdivbtSC_IN, fill=Model)) + geom_histogram(col='black') + geom_vline(xintercept=observed_ss$nucdivbtSC_IN)
#ggplot(prior_andersoni, aes(x=theta, fill=Model)) + geom_histogram(col='black') + geom_vline(xintercept=observed_ss$theta)
#

## Use parameter estimation to get an idea
tol <- c(0.01)
method <- c("rejection")

## select the summary statistics and create a dataframe with just these stats
library('abc')
touse <- c("pi","S","piwiC","piwiI","nucdivbtC_I","theta")
sumstat <- prior_andersoni[,touse]
observed_target <- observed_ss[,touse]
abcresults <- postpr(observed_target,index,sumstat, tol, method=method)
summary(abcresults)

## param est
## estimate parameter values
partouse <- c("ThetaAncestral", "DivergenceTime", "MigrationRate", "MigrationRate_Inland", "MigrationRate_Coastal", "myseed","Scale_Param", "freqA", "freqC", "freqG", "freqT", "titv", "invsites", "gammacat", "shape", "InlandProp", "CoastalProp")
params <- prior_andersoni[,partouse]
params[is.na(params)] <- 0
abcparam <- abc(observed_target,params,sumstat, tol, method=method)
summary(abcparam)

## plot posterior param estimates
## get posterior parameter estimates and plot them
posterior <- as.data.frame(abcparam$unadj.values)


pdf(file="andersoni_posterior_theta_s2.pdf")
plot(posterior$ThetaAncestral, ylim = c(0.01,10))
dev.off()

pdf(file="andersoni_posterior_DivergenceTime_s2.pdf")
plot(posterior$DivergenceTime,ylim=c(0.1,30))
dev.off()

pdf(file="andersoni_posterior_MigrationRate_s2.pdf")
plot(posterior$MigrationRate,ylim=c(1,10))
dev.off()

pdf(file="andersoni_posterior_MigrationRate_Inland_s2.pdf")
plot(posterior$MigrationRate_Inland,ylim=c(1,10))
dev.off()

pdf(file="andersoni_posterior_MigrationRate_Coastal_s2.pdf")
plot(posterior$MigrationRate_Coastal,ylim=c(1,10))
dev.off()


pdf(file="andersoni_posterior_InlandProp_s2.pdf")
plot(posterior$InlandProp,ylim=c(0.1,2))
dev.off()

pdf(file="andersoni_posterior_CoastalProp_s2.pdf")
plot(posterior$CoastalProp,ylim=c(0.1,2))
dev.off()

pdf(file="andersoni_posterior_scale_s2.pdf")
plot(posterior$Scale_Param,ylim=c(0.001,0.4))
dev.off()

