
## first, read in the prior and the observed data, and format the data for the analysis
library(abc)

## Set the working directory
setwd('/Users/msmith/Pro_COI_Revisions/ABC/Coeruleum/ModelFit_2pop_nobw/')

## read in the prior
prior_coeruleum <- read.table(file="coeruleum_difpops_noseq_s2_prior.txt",sep="\t")

## change the variable names
names(prior_coeruleum) <- c("Model","ThetaAncestral", "DivergenceTime_AV", "MigrationRate","MigrationRate_Inland", "MigrationRate_Coast", "myseed","Scale_Param", "InlandProp", "CoastalProp", "pi", "ss", "D", "thetaH", "H", "piI",  "piC",  "piC_I")
head(prior_coeruleum)

## store the model as a factor, and pull out a vector of these indices
prior_coeruleum$Model <- as.factor(prior_coeruleum$Model)
summary(prior_coeruleum$Model)
index <- as.vector(prior_coeruleum$Model)

## get the observed data
observed_ss <- data.frame(0.09500*574,180,0.2326618,18.6198,0.6389305,0.09819*574,0,55.077)
names(observed_ss)<- c("pi", "ss", "D", "thetaH", "H", "piC",  "piI",  "piC_I")
head(observed_ss)

## now, let's plot simulated and observed ss
pdf(file="coeruleum_modelfit_noseq_pi_s2.pdf")
hist(prior_coeruleum$pi)
abline(v=observed_ss$pi, lwd=2, col="blue")
dev.off()
sum(prior_coeruleum$pi<=observed_ss$pi)/length(prior_coeruleum$pi)

pdf(file="coeruleum_modelfit_noseq_ss_s2.pdf")
hist(prior_coeruleum$ss)
abline(v=observed_ss$ss, lwd=2, col="blue")
dev.off()
sum(prior_coeruleum$ss<=observed_ss$ss)/length(prior_coeruleum$ss)

pdf(file="coeruleum_modelfit_noseq_D_s2.pdf")
hist(prior_coeruleum$D)
abline(v=observed_ss$D, lwd=2, col="blue")
dev.off()
sum(prior_coeruleum$D<=observed_ss$D)/length(prior_coeruleum$D)

pdf(file="coeruleum_modelfit_noseq_thetaH_s2.pdf")
hist(prior_coeruleum$thetaH)
abline(v=observed_ss$thetaH, lwd=2, col="blue")
dev.off()
sum(prior_coeruleum$thetaH<=observed_ss$thetaH)/length(prior_coeruleum$thetaH)

pdf(file="coeruleum_modelfit_noseq_H_s2.pdf")
hist(prior_coeruleum$H)
abline(v=observed_ss$H, lwd=2, col="blue")
dev.off()
sum(prior_coeruleum$H>=observed_ss$H)/length(prior_coeruleum$H)

pdf(file="coeruleum_modelfit_noseq_piC_s2.pdf")
hist(prior_coeruleum$piC)
abline(v=observed_ss$piC, lwd=2, col="blue")
dev.off()
sum(prior_coeruleum$piC>=observed_ss$piC)/length(prior_coeruleum$piC)

pdf(file="coeruleum_modelfit_noseq_piI_s2.pdf")
hist(prior_coeruleum$piI)
abline(v=observed_ss$piI, lwd=2, col="blue")
dev.off()
sum(prior_coeruleum$piI<=observed_ss$piI)/length(prior_coeruleum$piI)

pdf(file="coeruleum_modelfit_noseq_piC_I_s2.pdf")
hist(prior_coeruleum$piC_I)
abline(v=observed_ss$piC_I, lwd=2, col="blue")
dev.off()
sum(prior_coeruleum$piC_I<=observed_ss$piC_I)/length(prior_coeruleum$piC_I)


#library(ggplot2)
#ggplot(prior_coeruleum, aes(x=pi, fill=Model)) + geom_histogram(col='black') + geom_vline(xintercept=observed_ss$pi)
#ggplot(prior_coeruleum, aes(x=ss, fill=Model)) + geom_histogram(col='black') + geom_vline(xintercept=observed_ss$ss)
#ggplot(prior_coeruleum, aes(x=D, fill=Model)) + geom_histogram(col='black') + geom_vline(xintercept=observed_ss$D)
#ggplot(prior_coeruleum, aes(x=thetaH, fill=Model)) + geom_histogram(col='black') + geom_vline(xintercept=observed_ss$thetaH)
#ggplot(prior_coeruleum, aes(x=H, fill=Model)) + geom_histogram(col='black') + geom_vline(xintercept=observed_ss$H)
#ggplot(prior_coeruleum, aes(x=piNC, fill=Model)) + geom_histogram(col='black') + geom_vline(xintercept=observed_ss$piNC)
#ggplot(prior_coeruleum, aes(x=piSC, fill=Model)) + geom_histogram(col='black') + geom_vline(xintercept=observed_ss$piSC)
#ggplot(prior_coeruleum, aes(x=piIN, fill=Model)) + geom_histogram(col='black') + geom_vline(xintercept=observed_ss$piIN)
#ggplot(prior_coeruleum, aes(x=piNC_SC, fill=Model)) + geom_histogram(col='black') + geom_vline(xintercept=observed_ss$piNC_SC)
#ggplot(prior_coeruleum, aes(x=piNC_IN, fill=Model)) + geom_histogram(col='black') + geom_vline(xintercept=observed_ss$piNC_IN)
#ggplot(prior_coeruleum, aes(x=piSC_IN, fill=Model)) + geom_histogram(col='black') + geom_vline(xintercept=observed_ss$piSC_IN)


## Use parameter estimation to get an idea
tol <- c(0.01)
method <- c("rejection")

## select the summary statistics and create a dataframe with just these stats
touse <- c("pi", "ss", "D", "thetaH", "H", "piC",  "piI",  "piC_I")
sumstat <- prior_coeruleum[,touse]
observed_target <- observed_ss[,touse]
abcresults <- postpr(observed_target,index,sumstat, tol, method=method)
summary(abcresults)

## param est
## estimate parameter values
partouse <- c("ThetaAncestral", "DivergenceTime_AV", "MigrationRate","MigrationRate_Inland", "MigrationRate_Coast", "myseed","Scale_Param", "InlandProp", "CoastalProp")
params <- prior_coeruleum[,partouse]
params[is.na(params)] <- 0

abcparam <- abc(observed_target,params,sumstat, tol, method=method)
summary(abcparam)

## plot posterior param estimates
## get posterior parameter estimates and plot them
posterior <- as.data.frame(abcparam$unadj.values)

pdf(file="coeruleum_posterior_ThetaAncestral_noseq_s2.pdf")
plot(posterior$ThetaAncestral, ylim = c(0.01,30))
dev.off()

pdf(file="coeruleum_posterior_DivergenceTime_AV_noseq_s2.pdf")
plot(posterior$DivergenceTime_AV,ylim=c(0.1,30))
dev.off()

pdf(file="coeruleum_posterior_MigrationRate_noseq_s2.pdf")
plot(posterior$MigrationRate,ylim=c(0,10))
dev.off()

pdf(file="coeruleum_posterior_MigrationRate_Inland_noseq_s2.pdf")
plot(posterior$MigrationRate_Inland,ylim=c(0,10))
dev.off()

pdf(file="coeruleum_posterior_MigrationRate_Coast_noseq_s2.pdf")
plot(posterior$MigrationRate_Coast,ylim=c(0,10))
dev.off()

pdf(file="coeruleum_posterior_InlandProp_noseq_s2.pdf")
plot(posterior$InlandProp,ylim=c(0.001,0.5))
dev.off()

pdf(file="coeruleum_posterior_CoastalProp_noseq_s2.pdf")
plot(posterior$CoastalProp,ylim=c(0.1,3))
dev.off()

