
## first, read in the prior and the observed data, and format the data for the analysis
library(abc)

## Set the working directory
setwd('/Users/msmith/Pro_COI_Revisions/ABC/Coeruleum/ModelFit_2pop_nobw/')

## read in the prior
prior_coeruleum <- read.table(file="coeruleum_difpops_prior.txt",sep="\t")

## change the variable names
names(prior_coeruleum)<- c("Model","ThetaAncestral", "DivergenceTime", "MigrationRate", "MigrationRate_Inland", "MigrationRate_Coastal", "myseed","Scale_Param", "freqA", "freqC", "freqG", "freqT", "titv", "invsites", "gammacat", "shape", "InlandProp","CoastalProp","pi","S","piwiI","piwiC","nucdivbtC_I","theta")
head(prior_coeruleum)

## store the model as a factor, and pull out a vector of these indices
prior_coeruleum$Model <- as.factor(prior_coeruleum$Model)
summary(prior_coeruleum$Model)
index <- as.vector(prior_coeruleum$Model)

## get the observed data
observed_ss <- read.table(file="../Sumstats_Obs/p_coer_2pops_nobw_sumstats_seq.txt",sep="\t",header=F)
names(observed_ss)<- c("pi","S","piwiC","piwiI","nucdivbtC_I","theta")
head(observed_ss)

## now, let's plot simulated and observed ss
pdf(file="coeruleum_modelfit_seq_pi.pdf")
hist(prior_coeruleum$pi)
abline(v=observed_ss$pi, lwd=2, col="blue")
dev.off()
sum(prior_coeruleum$pi>=observed_ss$pi)/length(prior_coeruleum$pi)

pdf(file="coeruleum_modelfit_seq_S.pdf")
hist(prior_coeruleum$S)
abline(v=observed_ss$S, lwd=2, col="blue")
dev.off()
sum(prior_coeruleum$S>=observed_ss$S)/length(prior_coeruleum$S)

pdf(file="coeruleum_modelfit_seq_piwiC.pdf")
hist(prior_coeruleum$piwiC)
abline(v=observed_ss$piwiC, lwd=2, col="blue")
dev.off()
sum(prior_coeruleum$piwiC>=observed_ss$piwiC)/length(prior_coeruleum$piwiC)

pdf(file="coeruleum_modelfit_seq_piwiI.pdf")
hist(prior_coeruleum$piwiI)
abline(v=observed_ss$piwiI, lwd=2, col="blue")
dev.off()
sum(prior_coeruleum$piwiI<=observed_ss$piwiI)/length(prior_coeruleum$piwiI)



pdf(file="coeruleum_modelfit_seq_nucdivbtC_I.pdf")
hist(prior_coeruleum$nucdivbtC_I)
abline(v=observed_ss$nucdivbtC_I, lwd=2, col="blue")
dev.off()
sum(prior_coeruleum$nucdivbtC_I>=observed_ss$nucdivbtC_I)/length(prior_coeruleum$nucdivbtC_I)

pdf(file="coeruleum_modelfit_seq_theta.pdf")
hist(prior_coeruleum$theta)
abline(v=observed_ss$theta, lwd=2, col="blue")
dev.off()
sum(prior_coeruleum$theta>=observed_ss$theta)/length(prior_coeruleum$theta)

#library(ggplot2)
#ggplot(prior_coeruleum, aes(x=pi, fill=Model)) + geom_histogram(col='black', binwidth = 0.01) + geom_vline(xintercept=observed_ss$pi)
#ggplot(prior_coeruleum, aes(x=S, fill=Model)) + geom_histogram(col='black') + geom_vline(xintercept=observed_ss$S)
#ggplot(prior_coeruleum, aes(x=piwiNC, fill=Model)) + geom_histogram(col='black') + geom_vline(xintercept=observed_ss$piwiNC)
#ggplot(prior_coeruleum, aes(x=piwiSC, fill=Model)) + geom_histogram(col='black') + geom_vline(xintercept=observed_ss$piwiSC)
#ggplot(prior_coeruleum, aes(x=piwiIN, fill=Model)) + geom_histogram(col='black') + geom_vline(xintercept=observed_ss$piwiIN)
#ggplot(prior_coeruleum, aes(x=nucdivbtNC_SC, fill=Model)) + geom_histogram(col='black') + geom_vline(xintercept=observed_ss$nucdivbtNC_SC)
#ggplot(prior_coeruleum, aes(x=nucdivbtNC_IN, fill=Model)) + geom_histogram(col='black') + geom_vline(xintercept=observed_ss$nucdivbtNC_IN)
#ggplot(prior_coeruleum, aes(x=nucdivbtSC_IN, fill=Model)) + geom_histogram(col='black') + geom_vline(xintercept=observed_ss$nucdivbtSC_IN)
#ggplot(prior_coeruleum, aes(x=theta, fill=Model)) + geom_histogram(col='black') + geom_vline(xintercept=observed_ss$theta)
#

## Use parameter estimation to get an idea
tol <- c(0.05)
method <- c("rejection")

## select the summary statistics and create a dataframe with just these stats
library('abc')
touse <- c("pi","S","piwiC","piwiI","nucdivbtC_I","theta")
sumstat <- prior_coeruleum[,touse]
observed_target <- observed_ss[,touse]
abcresults <- postpr(observed_target,index,sumstat, tol, method=method)
summary(abcresults)

## param est
## estimate parameter values
partouse <- c("ThetaAncestral", "DivergenceTime", "MigrationRate", "MigrationRate_Inland", "MigrationRate_Coastal", "myseed","Scale_Param", "freqA", "freqC", "freqG", "freqT", "titv", "invsites", "gammacat", "shape", "InlandProp", "CoastalProp")
params <- prior_coeruleum[,partouse]
params[is.na(params)] <- 0
abcparam <- abc(observed_target,params,sumstat, tol, method=method)
summary(abcparam)

## plot posterior param estimates
## get posterior parameter estimates and plot them
posterior <- as.data.frame(abcparam$unadj.values)


pdf(file="coeruleum_posterior_theta.pdf")
plot(posterior$ThetaAncestral, ylim = c(0.01,10))
dev.off()

pdf(file="coeruleum_posterior_DivergenceTime.pdf")
plot(posterior$DivergenceTime,ylim=c(0.1,30))
dev.off()

pdf(file="coeruleum_posterior_MigrationRate.pdf")
plot(posterior$MigrationRate,ylim=c(1,10))
dev.off()

pdf(file="coeruleum_posterior_MigrationRate_Inland.pdf")
plot(posterior$MigrationRate_Inland,ylim=c(1,10))
dev.off()

pdf(file="coeruleum_posterior_MigrationRate_Coastal.pdf")
plot(posterior$MigrationRate_Coastal,ylim=c(1,10))
dev.off()


pdf(file="coeruleum_posterior_InlandProp.pdf")
plot(posterior$InlandProp,ylim=c(0.1,2))
dev.off()

pdf(file="coeruleum_posterior_CoastalProp.pdf")
plot(posterior$CoastalProp,ylim=c(0.1,2))
dev.off()

pdf(file="coeruleum_posterior_scale.pdf")
plot(posterior$Scale_Param,ylim=c(0.001,0.4))
dev.off()

