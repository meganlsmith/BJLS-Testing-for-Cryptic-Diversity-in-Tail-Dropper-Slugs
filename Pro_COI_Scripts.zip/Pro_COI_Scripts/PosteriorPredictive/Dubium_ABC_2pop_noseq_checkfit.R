
## first, read in the prior and the observed data, and format the data for the analysis
library(abc)

## Set the working directory
setwd('/Users/msmith/Pro_COI_Revisions/ABC/Dubium/ModelFit_2pop_nobw/')

## read in the prior
prior_dubium <- read.table(file="dubium_difpops_noseq_s2_prior.txt",sep="\t")

## change the variable names
names(prior_dubium) <- c("Model","ThetaAncestral", "DivergenceTime_AV", "MigrationRate","MigrationRate_Inland", "MigrationRate_Coast", "myseed","Scale_Param", "InlandProp", "CoastalProp", "pi", "ss", "D", "thetaH", "H", "piI",  "piC",  "piC_I")
head(prior_dubium)

## store the model as a factor, and pull out a vector of these indices
prior_dubium$Model <- as.factor(prior_dubium$Model)
summary(prior_dubium$Model)
index <- as.vector(prior_dubium$Model)

## get the observed data
observed_ss <- data.frame(0.05026*574,90,0.8315201,16.51597,0.5644567,0.05096*574,0.00859*574,31.292)
names(observed_ss)<- c("pi", "ss", "D", "thetaH", "H", "piC",  "piI",  "piC_I")
head(observed_ss)

## now, let's plot simulated and observed ss
pdf(file="dubium_modelfit_noseq_pi_s2.pdf")
hist(prior_dubium$pi)
abline(v=observed_ss$pi, lwd=2, col="blue")
dev.off()
sum(prior_dubium$pi>=observed_ss$pi)/length(prior_dubium$pi)

pdf(file="dubium_modelfit_noseq_ss_s2.pdf")
hist(prior_dubium$ss)
abline(v=observed_ss$ss, lwd=2, col="blue")
dev.off()
sum(prior_dubium$ss<=observed_ss$ss)/length(prior_dubium$ss)

pdf(file="dubium_modelfit_noseq_D_s2.pdf")
hist(prior_dubium$D)
abline(v=observed_ss$D, lwd=2, col="blue")
dev.off()
sum(prior_dubium$D>=observed_ss$D)/length(prior_dubium$D)

pdf(file="dubium_modelfit_noseq_thetaH_s2.pdf")
hist(prior_dubium$thetaH)
abline(v=observed_ss$thetaH, lwd=2, col="blue")
dev.off()
sum(prior_dubium$thetaH<=observed_ss$thetaH)/length(prior_dubium$thetaH)

pdf(file="dubium_modelfit_noseq_H_s2.pdf")
hist(prior_dubium$H)
abline(v=observed_ss$H, lwd=2, col="blue")
dev.off()
sum(prior_dubium$H>=observed_ss$H)/length(prior_dubium$H)

pdf(file="dubium_modelfit_noseq_piC_s2.pdf")
hist(prior_dubium$piC)
abline(v=observed_ss$piC, lwd=2, col="blue")
dev.off()
sum(prior_dubium$piC>=observed_ss$piC)/length(prior_dubium$piC)

pdf(file="dubium_modelfit_noseq_piI_s2.pdf")
hist(prior_dubium$piI)
abline(v=observed_ss$piI, lwd=2, col="blue")
dev.off()
sum(prior_dubium$piI<=observed_ss$piI)/length(prior_dubium$piI)

pdf(file="dubium_modelfit_noseq_piC_I_s2.pdf")
hist(prior_dubium$piC_I)
abline(v=observed_ss$piC_I, lwd=2, col="blue")
dev.off()
sum(prior_dubium$piC_I<=observed_ss$piC_I)/length(prior_dubium$piC_I)


#library(ggplot2)
#ggplot(prior_dubium, aes(x=pi, fill=Model)) + geom_histogram(col='black') + geom_vline(xintercept=observed_ss$pi)
#ggplot(prior_dubium, aes(x=ss, fill=Model)) + geom_histogram(col='black') + geom_vline(xintercept=observed_ss$ss)
#ggplot(prior_dubium, aes(x=D, fill=Model)) + geom_histogram(col='black') + geom_vline(xintercept=observed_ss$D)
#ggplot(prior_dubium, aes(x=thetaH, fill=Model)) + geom_histogram(col='black') + geom_vline(xintercept=observed_ss$thetaH)
#ggplot(prior_dubium, aes(x=H, fill=Model)) + geom_histogram(col='black') + geom_vline(xintercept=observed_ss$H)
#ggplot(prior_dubium, aes(x=piNC, fill=Model)) + geom_histogram(col='black') + geom_vline(xintercept=observed_ss$piNC)
#ggplot(prior_dubium, aes(x=piSC, fill=Model)) + geom_histogram(col='black') + geom_vline(xintercept=observed_ss$piSC)
#ggplot(prior_dubium, aes(x=piIN, fill=Model)) + geom_histogram(col='black') + geom_vline(xintercept=observed_ss$piIN)
#ggplot(prior_dubium, aes(x=piNC_SC, fill=Model)) + geom_histogram(col='black') + geom_vline(xintercept=observed_ss$piNC_SC)
#ggplot(prior_dubium, aes(x=piNC_IN, fill=Model)) + geom_histogram(col='black') + geom_vline(xintercept=observed_ss$piNC_IN)
#ggplot(prior_dubium, aes(x=piSC_IN, fill=Model)) + geom_histogram(col='black') + geom_vline(xintercept=observed_ss$piSC_IN)


## Use parameter estimation to get an idea
tol <- c(0.01)
method <- c("rejection")

## select the summary statistics and create a dataframe with just these stats
touse <- c("pi", "ss", "D", "thetaH", "H", "piC",  "piI",  "piC_I")
sumstat <- prior_dubium[,touse]
observed_target <- observed_ss[,touse]
abcresults <- postpr(observed_target,index,sumstat, tol, method=method)
summary(abcresults)

## param est
## estimate parameter values
partouse <- c("ThetaAncestral", "DivergenceTime_AV", "MigrationRate","MigrationRate_Inland", "MigrationRate_Coast", "myseed","Scale_Param", "InlandProp", "CoastalProp")
params <- prior_dubium[,partouse]
params[is.na(params)] <- 0

abcparam <- abc(observed_target,params,sumstat, tol, method=method)
summary(abcparam)

## plot posterior param estimates
## get posterior parameter estimates and plot them
posterior <- as.data.frame(abcparam$unadj.values)

pdf(file="dubium_posterior_ThetaAncestral_noseq_s2.pdf")
plot(posterior$ThetaAncestral, ylim = c(0.01,20))
dev.off()

pdf(file="dubium_posterior_DivergenceTime_AV_noseq_s2.pdf")
plot(posterior$DivergenceTime_AV,ylim=c(0.1,30))
dev.off()

pdf(file="dubium_posterior_MigrationRate_noseq_s2.pdf")
plot(posterior$MigrationRate,ylim=c(0,10))
dev.off()

pdf(file="dubium_posterior_MigrationRate_Inland_noseq_s2.pdf")
plot(posterior$MigrationRate_Inland,ylim=c(0,10))
dev.off()

pdf(file="dubium_posterior_MigrationRate_Coast_noseq_s2.pdf")
plot(posterior$MigrationRate_Coast,ylim=c(0,10))
dev.off()

pdf(file="dubium_posterior_InlandProp_noseq_s2.pdf")
plot(posterior$InlandProp,ylim=c(0.1,2))
dev.off()

pdf(file="dubium_posterior_CoastalProp_noseq_s2.pdf")
plot(posterior$CoastalProp,ylim=c(0.1,2))
dev.off()

