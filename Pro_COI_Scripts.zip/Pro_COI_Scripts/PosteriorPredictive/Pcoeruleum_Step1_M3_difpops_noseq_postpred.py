#!/usr/bin/python
#import math 
#import random
import os
import random

"""We will store the output to a stats file and a params file. Since we will need to append to them later, here we check that the files are empty, and overwrite them if not."""
out = open("coeruleum.m3.difpops.noseq.stats.postpred.txt", "w")
out.close()
out = open("coeruleum.m3.difpops.noseq.params.postpred.txt", "w")
out.close()

"""Now, we set up the sample sizes. For this bit, the model groups the blues and wallowas populations with the coastal samples."""
Inland = 8
Coastal = 39
Total = 47 
"""Now, its time to simulate the data."""
"""ancient vicariance with symmetrical gene flow
this model generates %s=Nsam_coeruleum (71) chromosomes. We are simulating gene trees, and theta (4Nou) is set to a draw from the ThetaAncestral prior, where No is the subpopulation size.
there are two subpopulations. The inland population is listed first and consists of 10 chromosomes, while the coastal population is listed second and consists of 61 chromosomes.
we then set the migration parameter. mij is the fraction of subpopulation i which is made up of migrants from subpopulation j each generation. The elements of the migration matrix are 4Nomij. This value is drawn from MigrationRate_Inland.
we also specify a divergence event Specifically, at %s = DivergenceTime_AV (in 4No generations), all lineages from the inland population move into the coastal population.
In essence, at the present time, there is symmetric migration. At some point in the past, the inland and coastal populations merge.
This is a model of ancient divergence with symmetrical gene flow."""

def simdata(infile):
    count = 1
    theparams = open(infile)
    for line in theparams:
        if count > 1:
            """Get the parameters."""
            intheline = line.split(',')
            ThetaAncestral = intheline[0]
            DivergenceTime_AV = intheline[1]
            MigrationRate = intheline[2]
            MigrationRate_Inland = intheline[3]
            MigrationRate_Coastal = intheline[4]
            Scale_Param = intheline[5]
            InlandProp = intheline[6]
            CoastalProp = intheline[7].strip('\n')
                myseed = random.randint(0,32767)
                myseed1 = random.randint(0,32767)
                myseed2 = random.randint(0,32767)
                myseed3 = random.randint(0,32767)
                os.system("./ms %s 100 -t %s -I 2 %s %s %s -n 1 %s -n 2 %s -ej %s 1 2 -seeds %r %r %r | perl msSS.pl >> coeruleum.m3.difpops.noseq.stats.postpred.txt " % (Total, ThetaAncestral, Inland, Coastal, MigrationRate, InlandProp, CoastalProp, DivergenceTime_AV, myseed1, myseed2, myseed3))
                outfile=open('coeruleum.m3.difpops.noseq.params.postpred.txt', 'a')
                outfile.write('%s\t%s\t%s\t%s\tNA\tNA\t%s\t%s\t%s\t%s\n' % (3, ThetaAncestral, DivergenceTime_AV, MigrationRate, myseed,Scale_Param, InlandProp, CoastalProp))
        else:
            count +=1
simdata('Coeruleum_PostDist_noseq_M3_posterior.csv')
