#!/usr/bin/python
#import math 
#import random
import os
import random


"""We will store the output to a stats file and a params file. Since we will need to append to them later, here we check that the files are empty, and overwrite them if not."""
out = open("coeruleum.m3.difpops.stats.postpred.txt", "w")
out.close()
out = open("coeruleum.m3.difpops.params.postpred.txt", "w")
out.close()

"""Now, we set up the sample sizes. For this bit, the model groups the blues and wallowas populations with the coastal samples."""
Inland = 8
Coastal = 39
Total = 47
"""Set up the parts of the model that won't change."""
model = 'HKY'
length = 574
replicas = 1
partitions = 1
gammacat = 8

"""Now, its time to simulate the data."""
"""ancient vicariance with symmetrical gene flow
this model generates %s=Nsam_coeruleum (71) chromosomes. We are simulating gene trees, and theta (4Nou) is set to a draw from the ThetaAncestral prior, where No is the subpopulation size.
there are two subpopulations. The inland population is listed first and consists of 10 chromosomes, while the coastal population is listed second and consists of 61 chromosomes.
we then set the migration parameter. mij is the fraction of subpopulation i which is made up of migrants from subpopulation j each generation. The elements of the migration matrix are 4Nomij. This value is drawn from MigrationRate_Inlcoer.
we also specify a divergence event Specifically, at %s = DivergenceTime_AV (in 4No generations), all lineages from the inland population move into the coastal population.
In essence, at the present time, there is symmetric migration. At some point in the past, the inland and coastal populations merge.
This is a model of ancient divergence with symmetrical gene flow."""

def simdata(infile):
    count = 1
    theparams = open(infile)
    for line in theparams:
        if count > 1:
            """Get the parameters."""
            intheline = line.split(',')
            ThetaAncestral = intheline[0]
            DivergenceTime_AV = intheline[1]
            MigrationRate = intheline[2]
            MigrationRate_Inland = intheline[3]
            MigrationRate_Coastal = intheline[4]
            Scale_Param = intheline[5]
            freqA = intheline[6]
            freqC = intheline[7]
            freqG = intheline[8]
            freqT = intheline[9]
            titv = intheline[10]
            invsites = intheline[11]
            gammacat = intheline[12]
            shape = intheline[13]
            InlandProp = intheline[14]
            CoastalProp = intheline[15].strip('\n')
            for i in range(1,101):
                myseed = random.randint(0,32767)
                myseed1 = random.randint(0,32767)
                myseed2 = random.randint(0,32767)
                myseed3 = random.randint(0,32767)
                os.system("./ms %s 1 -T -t %s -I 2 %s %s %s -n 1 %s -n 2 %s -ej %s 1 2 -seeds %r %r %r | tail -n +4 | grep -v // > coer.m3.difpops.postpred.tree " % (Total, ThetaAncestral, Inland, Coastal, MigrationRate, InlandProp, CoastalProp, DivergenceTime_AV, myseed1, myseed2, myseed3))
                os.system("'/fs/project/PAS1181/Pro_COI_August2017/ABC/Seq-Gen-1.3.4/source/seq-gen' -z%s -m%s -l %s -n%s -p%s -s%s -f %s %s %s %s -t%s -i%s -g%s -a%s < coer.m3.difpops.postpred.tree > coeruleum.m3.difpops.seqgen.postpred.phy" % (myseed, model, length, replicas, partitions, Scale_Param, freqA, freqC, freqG, freqT, titv, invsites, gammacat, shape))
                os.system("python sumstats.py coeruleum.m3.difpops.seqgen.postpred.phy %s %s coeruleum.m3.difpops.stats.postpred.txt" % (Inland, Coastal))
                os.system("rm coeruleum.m3.difpops.seqgen.postpred.phy")
                os.system("rm coer.m3.difpops.postpred.tree")
                outfile=open('coeruleum.m3.difpops.params.postpred.txt', 'a')
                outfile.write('%s\t%s\t%s\t%s\tNA\tNA\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\n' % (3, ThetaAncestral, DivergenceTime_AV, MigrationRate, myseed,Scale_Param, freqA, freqC, freqG, freqT, titv, invsites, gammacat, shape, InlandProp, CoastalProp))
        else:
            count +=1
simdata('Coeruleum_PostDist_seq_M3_posterior.csv')
