#!/usr/bin/python
#import math 
#import random
import os
import random

#draws from the prior distribution 
#Priorsize = 100000
#Counter = 1

"""We will store the output to a stats file and a params file. Since we will need to append to them later, here we check that the files are empty, and overwrite them if not."""
out = open("dubium.m1.difpops.noseq.stats.postpred.txt", "w")
out.close()
out = open("dubium.m1.difpops.noseq.params.postpred.txt", "w")
out.close()

"""Now, we set up the sample sizes. For this bit, the model groups the blues and wallowas populations with the coastal samples."""
Inland = 8
Coastal = 27
Total = 35



"""Now, its time to simulate the data."""
"""this model generates %s=Nsam_dubium (36) chromosomes. We are simulating gene trees, and theta (4Nou) is set to a draw from the ThetaAncestral prior, where No is the subpopulation size.
there are two subpopulations. The inland population is listed first and consists of 10 chromosomes, while the coastal population is listed second and consists of 61 chromosomes.
we then set the migration parameter. mij is the fraction of subpopulation i which is made up of migrants from subpopulation j each generation. The elements of the migration matrix are 4Nomij. This value is drawn from MigrationRate_Coastal.
we also specify a divergence event Specifically, at %s = DivergenceTime (in 4No generations), all lineages from the inland population move into the coastal population.
In essence, at the present time, there is migration such that m 2 1 is the 4*No*fraction of subpopulation 2 (coast) that is made of migrants from subpopulation1 (inland) each generation. At some point in the past, the inland and coastal populations merge.
However, we're looking back in time, so...
This is a model of recent divergence with gene flow from the coastal to the inland population."""

def simdata(infile):
    count = 1
    theparams = open(infile)
    for line in theparams:
        if count > 1:
            """Get the parameters."""
            intheline = line.split(',')
            ThetaAncestral = intheline[0]
            DivergenceTime = intheline[1]
            MigrationRate = intheline[2]
            MigrationRate_Inland = intheline[3]
            MigrationRate_Coastal = intheline[4]
            Scale_Param = intheline[5]
            InlandProp = intheline[6]
            CoastalProp = intheline[7].strip('\n')
            myseed = random.randint(0,32767)
            myseed1 = random.randint(0,32767)
            myseed2 = random.randint(0,32767)
            myseed3 = random.randint(0,32767)
            os.system("./ms %s 100 -t %s -I 2 %s %s -n 1 %s -n 2 %s -m 1 2 0 -m 2 1 %s -ej %s 1 2 -seeds %r %r %r | perl msSS.pl >> dubium.m1.difpops.noseq.stats.postpred.txt " % (Total, ThetaAncestral, Inland, Coastal, InlandProp, CoastalProp, MigrationRate_Coastal, DivergenceTime, myseed1, myseed2, myseed3))
            outfile=open('dubium.m1.difpops.noseq.params.postpred.txt', 'a')
            outfile.write('%s\t%s\t%s\tNA\tNA\t%s\t%s\t%s\t%s\t%s\n' % (1, ThetaAncestral, DivergenceTime, MigrationRate_Coastal, myseed,Scale_Param, InlandProp, CoastalProp))
        else:
            count +=1
simdata('Dubium_PostDist_noseq_M1_posterior.csv')
