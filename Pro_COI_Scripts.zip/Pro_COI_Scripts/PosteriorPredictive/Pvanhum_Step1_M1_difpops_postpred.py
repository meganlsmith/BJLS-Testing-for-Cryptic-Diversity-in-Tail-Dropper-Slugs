#!/usr/bin/python
#import math 
#import random
import os
import random


"""We will store the output to a stats file and a params file. Since we will need to append to them later, here we check that the files are empty, and overwrite them if not."""
out = open("vanhum.m1.difpops.stats.postpred.txt", "w")
out.close()
out = open("vanhum.m1.difpops.params.postpred.txt", "w")
out.close()

"""Now, we set up the sample sizes. For this bit, the model groups the blues and wallowas populations with the coastal samples."""
Inland = 38
Coastal = 33
Total = 71

"""Set up the parts of the model that won't change."""
model = 'HKY'
length = 574
replicas = 1
partitions = 1
gammacat = 8

"""Now, its time to simulate the data."""
"""this model generates %s=Nsam_vanhum (36) chromosomes. We are simulating gene trees, and theta (4Nou) is set to a draw from the ThetaAncestral prior, where No is the subpopulation size.
there are two subpopulations. The inland population is listed first and consists of 10 chromosomes, while the coastal population is listed second and consists of 61 chromosomes.
we then set the migration parameter. mij is the fraction of subpopulation i which is made up of migrants from subpopulation j each generation. The elements of the migration matrix are 4Nomij. This value is drawn from MigrationRate_Coastal.
we also specify a divergence event Specifically, at %s = DivergenceTime (in 4No generations), all lineages from the inland population move into the coastal population.
In essence, at the present time, there is migration such that m 2 1 is the 4*No*fraction of subpopulation 2 (coast) that is made of migrants from subpopulation1 (inland) each generation. At some point in the past, the inland and coastal populations merge.
However, we're looking back in time, so...
This is a model of recent divergence with gene flow from the coastal to the inland population."""

def simdata(infile):
    count = 1
    theparams = open(infile)
    for line in theparams:
        if count > 1:
            """Get the parameters."""
            intheline = line.split(',')
            ThetaAncestral = intheline[0]
            DivergenceTime = intheline[1]
            MigrationRate = intheline[2]
            MigrationRate_Inland = intheline[3]
            MigrationRate_Coastal = intheline[4]
            Scale_Param = intheline[5]
            freqA = intheline[6]
            freqC = intheline[7]
            freqG = intheline[8]
            freqT = intheline[9]
            titv = intheline[10]
            invsites = intheline[11]
            gammacat = intheline[12]
            shape = intheline[13]
            InlandProp = intheline[14]
            CoastalProp = intheline[15].strip('\n')
            for i in range(1,101):
                myseed = random.randint(0,32767)
                myseed1 = random.randint(0,32767)
                myseed2 = random.randint(0,32767)
                myseed3 = random.randint(0,32767)
                os.system("./ms %s 1 -T -t %s -I 2 %s %s -n 1 %s -n 2 %s -m 1 2 0 -m 2 1 %s -ej %s 1 2 -seeds %r %r %r | tail -n +4 | grep -v // > and.m1.difpops.postpred.tree " % (Total, ThetaAncestral, Inland, Coastal, InlandProp, CoastalProp, MigrationRate_Coastal, DivergenceTime, myseed1, myseed2, myseed3))
                os.system("'/fs/project/PAS1181/Pro_COI_August2017/ABC/Seq-Gen-1.3.4/source/seq-gen' -z%s -m%s -l %s -n%s -p%s -s%s -f %s %s %s %s -t%s -i%s -g%s -a%s < and.m1.difpops.postpred.tree > vanhum.m1.difpops.seqgen.postpred.phy" % (myseed, model, length, replicas, partitions, Scale_Param, freqA, freqC, freqG, freqT, titv, invsites, gammacat, shape))
                os.system("python sumstats.py vanhum.m1.difpops.seqgen.postpred.phy %s %s vanhum.m1.difpops.stats.postpred.txt" % (Inland, Coastal))
                os.system("rm vanhum.m1.difpops.seqgen.postpred.phy")
                os.system("rm and.m1.difpops.postpred.tree")
                outfile=open('vanhum.m1.difpops.params.postpred.txt', 'a')
                outfile.write('%s\t%s\t%s\tNA\tNA\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\n' % (1, ThetaAncestral, DivergenceTime, MigrationRate_Coastal, myseed,Scale_Param, freqA, freqC, freqG, freqT, titv, invsites, gammacat, shape, InlandProp, CoastalProp))
        else:
            count +=1
simdata('VanHum_PostDist_seq_M1_posterior.csv')
