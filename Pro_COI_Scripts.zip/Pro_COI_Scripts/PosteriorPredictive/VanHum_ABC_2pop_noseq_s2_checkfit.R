
## first, read in the prior and the observed data, and format the data for the analysis
library(abc)

## Set the working directory
setwd('/Users/msmith/Pro_COI_Revisions/ABC/VanHum/ModelFit_2pop_nobw/')

## read in the prior
prior_vanhum <- read.table(file="vanhum_difpops_noseq_s2_prior.txt",sep="\t")

## change the variable names
## change the variable names
## change the variable names
## change the variable names
names(prior_vanhum) <- c("Model","ThetaAncestral", "DivergenceTime_AV", "MigrationRate","MigrationRate_Inland", "MigrationRate_Coast", "myseed","Scale_Param", "InlandProp", "CoastalProp", "pi", "ss", "D", "thetaH", "H", "piI",  "piC",  "piC_I")
head(prior_vanhum)

## store the model as a factor, and pull out a vector of these indices
prior_vanhum$Model <- as.factor(prior_vanhum$Model)
summary(prior_vanhum$Model)
index <- as.vector(prior_vanhum$Model)

## read in the observed summary statistics and format them correctly.
## read in the prior
## get the observed data
observed_ss <- data.frame(0.08602*574, 172, -0.06922251, 15.45956, 0.4366815, 0.08008*574, 0.04910*574, 62.691)
names(observed_ss)<- c("pi", "ss", "D", "thetaH", "H", "piC",  "piI",  "piC_I")
head(observed_ss)

## now, let's plot simulated and observed ss
pdf(file="vanhum_modelfit_noseq_pi_s2.pdf")
hist(prior_vanhum$pi)
abline(v=observed_ss$pi, lwd=2, col="blue")
dev.off()
sum(prior_vanhum$pi<=observed_ss$pi)/length(prior_vanhum$pi)

pdf(file="vanhum_modelfit_noseq_ss_s2.pdf")
hist(prior_vanhum$ss)
abline(v=observed_ss$ss, lwd=2, col="blue")
dev.off()
sum(prior_vanhum$ss<=observed_ss$ss)/length(prior_vanhum$ss)

pdf(file="vanhum_modelfit_noseq_D_s2.pdf")
hist(prior_vanhum$D)
abline(v=observed_ss$D, lwd=2, col="blue")
dev.off()
sum(prior_vanhum$D<=observed_ss$D)/length(prior_vanhum$D)

pdf(file="vanhum_modelfit_noseq_thetaH_s2.pdf")
hist(prior_vanhum$thetaH)
abline(v=observed_ss$thetaH, lwd=2, col="blue")
dev.off()
sum(prior_vanhum$thetaH<=observed_ss$thetaH)/length(prior_vanhum$thetaH)

pdf(file="vanhum_modelfit_noseq_H_s2.pdf")
hist(prior_vanhum$H)
abline(v=observed_ss$H, lwd=2, col="blue")
dev.off()
sum(prior_vanhum$H<=observed_ss$H)/length(prior_vanhum$H)

pdf(file="vanhum_modelfit_noseq_piC_s2.pdf")
hist(prior_vanhum$piC)
abline(v=observed_ss$piC, lwd=2, col="blue")
dev.off()
sum(prior_vanhum$piC>=observed_ss$piC)/length(prior_vanhum$piC)

pdf(file="vanhum_modelfit_noseq_piI_s2.pdf")
hist(prior_vanhum$piI)
abline(v=observed_ss$piI, lwd=2, col="blue")
dev.off()
sum(prior_vanhum$piI>=observed_ss$piI)/length(prior_vanhum$piI)



pdf(file="vanhum_modelfit_noseq_piC_I_s2.pdf")
hist(prior_vanhum$piC_I)
abline(v=observed_ss$piC_I, lwd=2, col="blue")
dev.off()
sum(prior_vanhum$piC_I<=observed_ss$piC_I)/length(prior_vanhum$piC_I)

pdf(file="vanhum_modelfit_noseq_theta_s2.pdf")
hist(prior_vanhum$theta)
abline(v=observed_ss$theta, lwd=2, col="blue")
dev.off()
sum(prior_vanhum$theta>=observed_ss$theta)/length(prior_vanhum$theta)

#library(ggplot2)
#ggplot(prior_vanhum, aes(x=pi, fill=Model)) + geom_histogram(col='black', binwidth = 0.01) + geom_vline(xintercept=observed_ss$pi)
#ggplot(prior_vanhum, aes(x=S, fill=Model)) + geom_histogram(col='black') + geom_vline(xintercept=observed_ss$S)
#ggplot(prior_vanhum, aes(x=piwiNC, fill=Model)) + geom_histogram(col='black') + geom_vline(xintercept=observed_ss$piwiNC)
#ggplot(prior_vanhum, aes(x=piwiSC, fill=Model)) + geom_histogram(col='black') + geom_vline(xintercept=observed_ss$piwiSC)
#ggplot(prior_vanhum, aes(x=piwiIN, fill=Model)) + geom_histogram(col='black') + geom_vline(xintercept=observed_ss$piwiIN)
#ggplot(prior_vanhum, aes(x=nucdivbtNC_SC, fill=Model)) + geom_histogram(col='black') + geom_vline(xintercept=observed_ss$nucdivbtNC_SC)
#ggplot(prior_vanhum, aes(x=nucdivbtNC_IN, fill=Model)) + geom_histogram(col='black') + geom_vline(xintercept=observed_ss$nucdivbtNC_IN)
#ggplot(prior_vanhum, aes(x=nucdivbtSC_IN, fill=Model)) + geom_histogram(col='black') + geom_vline(xintercept=observed_ss$nucdivbtSC_IN)
#ggplot(prior_vanhum, aes(x=theta, fill=Model)) + geom_histogram(col='black') + geom_vline(xintercept=observed_ss$theta)
#

## Use parameter estimation to get an idea
tol <- c(0.01)
method <- c("rejection")

## select the summary statistics and create a dataframe with just these stats
library('abc')
touse <- c("pi","S","piwiC","piwiI","nucdivbtC_I","theta")
sumstat <- prior_vanhum[,touse]
observed_target <- observed_ss[,touse]
abcresults <- postpr(observed_target,index,sumstat, tol, method=method)
summary(abcresults)

## param est
## estimate parameter values
partouse <- c("ThetaAncestral", "DivergenceTime", "MigrationRate", "MigrationRate_Inland", "MigrationRate_Coastal", "myseed","Scale_Param", "freqA", "freqC", "freqG", "freqT", "titv", "invsites", "gammacat", "shape", "InlandProp", "CoastalProp")
params <- prior_vanhum[,partouse]
params[is.na(params)] <- 0
abcparam <- abc(observed_target,params,sumstat, tol, method=method)
summary(abcparam)

## plot posterior param estimates
## get posterior parameter estimates and plot them
posterior <- as.data.frame(abcparam$unadj.values)


pdf(file="vanhum_posterior_theta_noseq_s2.pdf")
plot(posterior$ThetaAncestral, ylim = c(0.01,10))
dev.off()

pdf(file="vanhum_posterior_DivergenceTime_noseq_s2.pdf")
plot(posterior$DivergenceTime,ylim=c(0.1,30))
dev.off()

pdf(file="vanhum_posterior_MigrationRate_noseq_s2.pdf")
plot(posterior$MigrationRate,ylim=c(1,10))
dev.off()

pdf(file="vanhum_posterior_MigrationRate_Inland_noseq_s2.pdf")
plot(posterior$MigrationRate_Inland,ylim=c(1,10))
dev.off()

pdf(file="vanhum_posterior_MigrationRate_Coastal_noseq_s2.pdf")
plot(posterior$MigrationRate_Coastal,ylim=c(1,10))
dev.off()


pdf(file="vanhum_posterior_InlandProp_noseq_s2.pdf")
plot(posterior$InlandProp,ylim=c(0.1,2))
dev.off()

pdf(file="vanhum_posterior_CoastalProp_noseq_s2.pdf")
plot(posterior$CoastalProp,ylim=c(0.1,2))
dev.off()

pdf(file="vanhum_posterior_scale_noseq_s2.pdf")
plot(posterior$Scale_Param,ylim=c(0.001,0.4))
dev.off()

