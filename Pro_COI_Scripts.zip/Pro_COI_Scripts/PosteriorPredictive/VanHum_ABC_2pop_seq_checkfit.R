
## first, read in the prior and the observed data, and format the data for the analysis
library(abc)

## Set the working directory
setwd('/Users/msmith/Pro_COI_Revisions/ABC/VanHum/ModelFit_2pop_nobw/')

## read in the prior
prior_vanhum <- read.table(file="vanhum_difpops_prior.txt",sep="\t")

## change the variable names
names(prior_vanhum)<- c("Model","ThetaAncestral", "DivergenceTime", "MigrationRate", "MigrationRate_Inland", "MigrationRate_Coastal", "myseed","Scale_Param", "freqA", "freqC", "freqG", "freqT", "titv", "invsites", "gammacat", "shape", "InlandProp","CoastalProp","pi","S","piwiI","piwiC","nucdivbtC_I","theta")
head(prior_vanhum)

## store the model as a factor, and pull out a vector of these indices
prior_vanhum$Model <- as.factor(prior_vanhum$Model)
summary(prior_vanhum$Model)
index <- as.vector(prior_vanhum$Model)

## get the observed data
observed_ss <- read.table(file="../Sumstats_Obs/p_vanhum_2pops_nobw_sumstats_seq.txt",sep="\t",header=F)
names(observed_ss)<- c("pi","S","piwiC","piwiI","nucdivbtC_I","theta")
head(observed_ss)

## now, let's plot simulated and observed ss
pdf(file="vanhum_modelfit_seq_pi.pdf")
hist(prior_vanhum$pi)
abline(v=observed_ss$pi, lwd=2, col="blue")
dev.off()
sum(prior_vanhum$pi<=observed_ss$pi)/length(prior_vanhum$pi)

pdf(file="vanhum_modelfit_seq_S.pdf")
hist(prior_vanhum$S)
abline(v=observed_ss$S, lwd=2, col="blue")
dev.off()
sum(prior_vanhum$S>=observed_ss$S)/length(prior_vanhum$S)

pdf(file="vanhum_modelfit_seq_piwiC.pdf")
hist(prior_vanhum$piwiC)
abline(v=observed_ss$piwiC, lwd=2, col="blue")
dev.off()
sum(prior_vanhum$piwiC<=observed_ss$piwiC)/length(prior_vanhum$piwiC)

pdf(file="vanhum_modelfit_seq_piwiI.pdf")
hist(prior_vanhum$piwiI)
abline(v=observed_ss$piwiI, lwd=2, col="blue")
dev.off()
sum(prior_vanhum$piwiI<=observed_ss$piwiI)/length(prior_vanhum$piwiI)



pdf(file="vanhum_modelfit_seq_nucdivbtC_I.pdf")
hist(prior_vanhum$nucdivbtC_I)
abline(v=observed_ss$nucdivbtC_I, lwd=2, col="blue")
dev.off()
sum(prior_vanhum$nucdivbtC_I>=observed_ss$nucdivbtC_I)/length(prior_vanhum$nucdivbtC_I)

pdf(file="vanhum_modelfit_seq_theta.pdf")
hist(prior_vanhum$theta)
abline(v=observed_ss$theta, lwd=2, col="blue")
dev.off()
sum(prior_vanhum$theta>=observed_ss$theta)/length(prior_vanhum$theta)

#library(ggplot2)
#ggplot(prior_vanhum, aes(x=pi, fill=Model)) + geom_histogram(col='black', binwidth = 0.01) + geom_vline(xintercept=observed_ss$pi)
#ggplot(prior_vanhum, aes(x=S, fill=Model)) + geom_histogram(col='black') + geom_vline(xintercept=observed_ss$S)
#ggplot(prior_vanhum, aes(x=piwiNC, fill=Model)) + geom_histogram(col='black') + geom_vline(xintercept=observed_ss$piwiNC)
#ggplot(prior_vanhum, aes(x=piwiSC, fill=Model)) + geom_histogram(col='black') + geom_vline(xintercept=observed_ss$piwiSC)
#ggplot(prior_vanhum, aes(x=piwiIN, fill=Model)) + geom_histogram(col='black') + geom_vline(xintercept=observed_ss$piwiIN)
#ggplot(prior_vanhum, aes(x=nucdivbtNC_SC, fill=Model)) + geom_histogram(col='black') + geom_vline(xintercept=observed_ss$nucdivbtNC_SC)
#ggplot(prior_vanhum, aes(x=nucdivbtNC_IN, fill=Model)) + geom_histogram(col='black') + geom_vline(xintercept=observed_ss$nucdivbtNC_IN)
#ggplot(prior_vanhum, aes(x=nucdivbtSC_IN, fill=Model)) + geom_histogram(col='black') + geom_vline(xintercept=observed_ss$nucdivbtSC_IN)
#ggplot(prior_vanhum, aes(x=theta, fill=Model)) + geom_histogram(col='black') + geom_vline(xintercept=observed_ss$theta)
#

## Use parameter estimation to get an idea
tol <- c(0.01)
method <- c("rejection")

## select the summary statistics and create a dataframe with just these stats
library('abc')
touse <- c("pi","S","piwiC","piwiI","nucdivbtC_I","theta")
sumstat <- prior_vanhum[,touse]
observed_target <- observed_ss[,touse]
abcresults <- postpr(observed_target,index,sumstat, tol, method=method)
summary(abcresults)

## param est
## estimate parameter values
partouse <- c("ThetaAncestral", "DivergenceTime", "MigrationRate", "MigrationRate_Inland", "MigrationRate_Coastal", "myseed","Scale_Param", "freqA", "freqC", "freqG", "freqT", "titv", "invsites", "gammacat", "shape", "InlandProp", "CoastalProp")
params <- prior_vanhum[,partouse]
params[is.na(params)] <- 0
abcparam <- abc(observed_target,params,sumstat, tol, method=method)
summary(abcparam)

## plot posterior param estimates
## get posterior parameter estimates and plot them
posterior <- as.data.frame(abcparam$unadj.values)


pdf(file="vanhum_posterior_theta.pdf")
plot(posterior$ThetaAncestral, ylim = c(0.01,10))
dev.off()

pdf(file="vanhum_posterior_DivergenceTime.pdf")
plot(posterior$DivergenceTime,ylim=c(0.1,30))
dev.off()

pdf(file="vanhum_posterior_MigrationRate.pdf")
plot(posterior$MigrationRate,ylim=c(1,10))
dev.off()

pdf(file="vanhum_posterior_MigrationRate_Inland.pdf")
plot(posterior$MigrationRate_Inland,ylim=c(1,10))
dev.off()

pdf(file="vanhum_posterior_MigrationRate_Coastal.pdf")
plot(posterior$MigrationRate_Coastal,ylim=c(1,10))
dev.off()


pdf(file="vanhum_posterior_InlandProp.pdf")
plot(posterior$InlandProp,ylim=c(0.1,2))
dev.off()

pdf(file="vanhum_posterior_CoastalProp.pdf")
plot(posterior$CoastalProp,ylim=c(0.1,2))
dev.off()

pdf(file="vanhum_posterior_scale.pdf")
plot(posterior$Scale_Param,ylim=c(0.001,0.4))
dev.off()

