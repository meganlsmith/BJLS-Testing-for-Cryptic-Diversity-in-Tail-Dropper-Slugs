#!/usr/bin/python
#import math 
#import random
import os
import random

#draws from the prior distribution 
#Priorsize = 100000
#Counter = 1

"""We will store the output to a stats file and a params file. Since we will need to append to them later, here we check that the files are empty, and overwrite them if not."""
out = open("coeruleum.m1.difpops.noseq.stats.txt", "w")
out.close()
out = open("coeruleum.m1.difpops.noseq.params.txt", "w")
out.close()

"""Now, we set up the sample sizes. For this bit, the model groups the blues and wallowas populations with the coastal samples."""
Inland = 8
Coastal = 39
Total = 47



"""Now, its time to simulate the data."""
"""this model generates %s=Nsam_coeruleum (36) chromosomes. We are simulating gene trees, and theta (4Nou) is set to a draw from the ThetaAncestral prior, where No is the subpopulation size.
there are two subpopulations. The inland population is listed first and consists of 10 chromosomes, while the coastal population is listed second and consists of 61 chromosomes.
we then set the migration parameter. mij is the fraction of subpopulation i which is made up of migrants from subpopulation j each generation. The elements of the migration matrix are 4Nomij. This value is drawn from MigrationRate_Coastal.
we also specify a divergence event Specifically, at %f = DivergenceTime (in 4No generations), all lineages from the inland population move into the coastal population.
In essence, at the present time, there is migration such that m 2 1 is the 4*No*fraction of subpopulation 2 (coast) that is made of migrants from subpopulation1 (inland) each generation. At some point in the past, the inland and coastal populations merge.
However, we're looking back in time, so...
This is a model of recent divergence with gene flow from the coastal to the inland population."""

def simdata(nreps):
    counter=0
    while counter < nreps:
	InlandProp = random.uniform(0.001,0.5)
	CoastalProp = random.uniform(1,5)
        ThetaAncestral = random.uniform(0.1,30)
        Scale_Param = random.uniform(0,.4)
        DivergenceTime = random.uniform(.1, 3)
        MigrationRate_Coastal = random.uniform(1,10)
        myseed = random.randint(0,32767)
        myseed1 = random.randint(0,32767)
        myseed2 = random.randint(0,32767)
        myseed3 = random.randint(0,32767)
        os.system("./ms %s 1 -t %f -I 2 %s %s -n 1 %s -n 2 %s -m 1 2 0 -m 2 1 %f -ej %f 1 2 -seeds %r %r %r | perl msSS.pl >> coeruleum.m1.difpops.noseq.stats.txt " % (Total, ThetaAncestral, Inland, Coastal, InlandProp, CoastalProp, MigrationRate_Coastal, DivergenceTime, myseed1, myseed2, myseed3))
        outfile=open('coeruleum.m1.difpops.noseq.params.txt', 'a')
        outfile.write('%s\t%f\t%f\tNA\tNA\t%f\t%s\t%f\t%s\t%s\n' % (1, ThetaAncestral, DivergenceTime, MigrationRate_Coastal, myseed,Scale_Param, InlandProp, CoastalProp))
        counter+=1
simdata(100000)
