#!/usr/bin/python
#import math 
#import random
import os
import random

#draws from the prior distribution 
#Priorsize = 100000
#Counter = 1


"""We will store the output to a stats file and a params file. Since we will need to append to them later, here we check that the files are empty, and overwrite them if not."""
out = open("dubium.m3.difpops.noseq.stats.txt", "w")
out.close()
out = open("dubium.m3.difpops.noseq.params.txt", "w")
out.close()

"""Now, we set up the sample sizes. For this bit, the model groups the blues and wallowas populations with the coastal samples."""
Inland = 8
Coastal = 27
Total = 35

"""Now, its time to simulate the data."""
"""ancient vicariance with symmetrical gene flow
this model generates %s=Nsam_dubium (71) chromosomes. We are simulating gene trees, and theta (4Nou) is set to a draw from the ThetaAncestral prior, where No is the subpopulation size.
there are two subpopulations. The inland population is listed first and consists of 10 chromosomes, while the coastal population is listed second and consists of 61 chromosomes.
we then set the migration parameter. mij is the fraction of subpopulation i which is made up of migrants from subpopulation j each generation. The elements of the migration matrix are 4Nomij. This value is drawn from MigrationRate_Inland.
we also specify a divergence event Specifically, at %f = DivergenceTime_AV (in 4No generations), all lineages from the inland population move into the coastal population.
In essence, at the present time, there is symmetric migration. At some point in the past, the inland and coastal populations merge.
This is a model of ancient divergence with symmetrical gene flow."""

def simdata(nreps):
    counter = 0
    while counter < nreps:
        InlandProp = random.uniform(0.1,2)
        CoastalProp = random.uniform(0.1,2)
        ThetaAncestral = random.uniform(0.1,20)
        Scale_Param = random.uniform(0,.4)
        DivergenceTime_AV = random.uniform(1, 30)
        MigrationRate = random.uniform(1,10)
        myseed = random.randint(0,32767)
        myseed1 = random.randint(0,32767)
        myseed2 = random.randint(0,32767)
        myseed3 = random.randint(0,32767)
        os.system("./ms %s 1 -t %f -I 2 %s %s %f -n 1 %s -n 2 %s -ej %f 1 2 -seeds %r %r %r | perl msSS.pl >> dubium.m3.difpops.noseq.stats.txt " % (Total, ThetaAncestral, Inland, Coastal, MigrationRate, InlandProp, CoastalProp, DivergenceTime_AV, myseed1, myseed2, myseed3))
        outfile=open('dubium.m3.difpops.noseq.params.txt', 'a')
        outfile.write('%s\t%f\t%f\t%f\tNA\tNA\t%s\t%f\t%s\t%s\n' % (3, ThetaAncestral, DivergenceTime_AV, MigrationRate, myseed,Scale_Param, InlandProp, CoastalProp))
        counter+=1
simdata(100000)
