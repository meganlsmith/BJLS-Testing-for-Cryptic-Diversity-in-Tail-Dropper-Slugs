#!/usr/bin/python
#import math 
#import random
import os
import random

#draws from the prior distribution 
#Priorsize = 100000
#Counter = 1

"""We need to look at the output from MrBayes and draw, at random, 100,000 sets of parameters to use in the input file.
This function will take three arguments: the input log file name, the number of sets of parameters you need, and the name of the output file.
The function will open the infile, draw a random sample of N lines, and write these lines to the output file."""
def randompars(infile, nlines, outfile): # define the function
    with open(infile) as f: # with the infile open
        lines = random.sample(f.readlines(),nlines) # randomly sample nlines
    paramsout = open(outfile,'w') # open the outfile
    for item in lines: # for each item in the set of randomly chosen lines
        paramsout.write(str(item)) # write the item ot the outfile
    paramsout.close() # close the outfile.

randompars('dubium_nobw.log',100000,'Pdubium_m4_difpops.log')


"""We will store the output to a stats file and a params file. Since we will need to append to them later, here we check that the files are empty, and overwrite them if not."""
out = open("dubium.m4.difpops.stats.txt", "w")
out.close()
out = open("dubium.m4.difpops.params.txt", "w")
out.close()

"""Now, we set up the sample sizes. For this bit, the model groups the blues and wallowas populations with the coastal samples."""
Inland = 8
Coastal = 27
Total = 35

"""Set up the parts of the model that won't change."""
model = 'HKY'
length = 574
replicas = 1
partitions = 1
gammacat = 8

"""This function will calculate ti/tv from kappa."""
def titvcalc(piA,piC,piG,piT,kappat):
    piA = float(piA)
    piC = float(piC)
    piG = float(piG)
    piT = float(piT)
    kappat = float(kappat)
    titv = ((piT*piC+piA*piG)*kappat)/((piT+piC)*(piA+piG))
    return titv

"""Now, its time to simulate the data."""
"""ancient vicariance with symmetrical gene flow
this model generates %s=Nsam_dubium (71) chromosomes. We are simulating gene trees, and theta (4Nou) is set to a draw from the ThetaAncestral prior, where No is the subpopulation size.
there are two subpopulations. The inland population is listed first and consists of 10 chromosomes, while the coastal population is listed second and consists of 61 chromosomes.
we then set the migration parameter. mij is the fraction of subpopulation i which is made up of migrants from subpopulation j each generation. The elements of the migration matrix are 4Nomij. This value is drawn from MigrationRate_Inland.
we also specify a divergence event Specifically, at %f = DivergenceTime_AV (in 4No generations), all lineages from the inland population move into the coastal population.
In essence, at the present time, there is symmetric migration. At some point in the past, the inland and coastal populations merge.
This is a model of ancient divergence with symmetrical gene flow."""

def simdata(infile):
    theparams = open(infile)
    for line in theparams:
        """Get the parameters."""
        intheline = line.split('\t')
        InlandProp = random.uniform(0.01,2)
        CoastalProp = random.uniform(0.1,2)
        freqA = intheline[5]
        freqC = intheline[6]
        freqG = intheline[7]
        freqT = intheline[8]
        kappa = intheline[4]
        titv = titvcalc(freqA,freqC,freqG,freqT,kappa)
        invsites = intheline[9].strip('\n')
        ThetaAncestral = random.uniform(0.1,10)
        Scale_Param = random.uniform(0.001,.4)
        DivergenceTime_AV = random.uniform(1, 30)
        MigrationRate = random.uniform(1,10)
        myseed = random.randint(0,32767)
        myseed1 = random.randint(0,32767)
        myseed2 = random.randint(0,32767)
        myseed3 = random.randint(0,32767)
        os.system("./ms %s 1 -T -t %f -I 2 %s %s -n 1 %s -n 2 %s -ej %f 1 2 -seeds %r %r %r | tail -n +4 | grep -v // > dub.m4.difpops.tree " % (Total, ThetaAncestral, Inland, Coastal, InlandProp, CoastalProp, DivergenceTime_AV, myseed1, myseed2, myseed3))
        os.system("'/fs/project/PAS1181/Pro_COI_August2017/ABC/Seq-Gen-1.3.4/source/seq-gen' -z%f -m%s -l %f -n%f -p%f -s%f -f %s %s %s %s -t%s -i%s < dub.m4.difpops.tree > dubium.m4.difpops.seqgen.phy" % (myseed, model, length, replicas, partitions, Scale_Param, freqA, freqC, freqG, freqT, titv, invsites))
        os.system("python sumstats.py dubium.m4.difpops.seqgen.phy %s %s dubium.m4.difpops.stats.txt" % (Inland, Coastal))
        os.system("rm dubium.m4.difpops.seqgen.phy")
        os.system("rm dub.m4.difpops.tree")
        outfile=open('dubium.m4.difpops.params.txt', 'a')
        outfile.write('%s\t%f\t%f\tNA\tNA\tNA\t%s\t%f\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\n' % (4, ThetaAncestral, DivergenceTime_AV, myseed,Scale_Param, freqA, freqC, freqG, freqT, titv, invsites, InlandProp, CoastalProp))

simdata('Pdubium_m4_difpops.log')
