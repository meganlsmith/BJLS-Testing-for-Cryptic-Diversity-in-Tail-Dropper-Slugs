# a python script to calculate summary statistics from phylip file
from sys import argv

# parse the arguments
script,filename, outfile = argv

## to calculate pi, we need to generate a list of unique sequences and the number of times they occur

def seqlist():
    """This is a function that creates a dictionary with unique sequences as keys, 
    and the number of times each unique sequence occurs as a value."""
    count = 1 ## start a counter, will be used to skip the first line
    curfile = open(filename, "r") ## open the input file, given as argument to script
    seqdict = {} ## create an empty dictionary
    nsam =-1 ## start a counter to record the number of samples, skipping the first line
    for line in curfile: ## loop through the file
        if count >1: ## if we aren't on the first line
            curline = line.split()[1] ## split based on the spaces
            if curline in seqdict.keys():## if the sequence is already a key in the dictionary
                seqdict[curline]+=1 ## then increase the count
            else: ## if it isn't in the dictionary yet
                seqdict[curline] = 1 ## then add it
        elif count == 1: ## skip the first line
            count +=1
        nsam+=1 ## count the samples
    return seqdict,nsam ## return the dictionary and the number of samples

def counthaplotypes(seqdict):
    """This is a function that counts the unique haplotypes in the dataset.
    It takes as an argument the output of seqlist()."""
    haplocount = len(seqdict.keys())
    return haplocount
    
def diff_letters(a,b):
    """This is a function that counts the number of differences between two strings.
    It will be used to calculate pi, and takes two strings as input."""
    return sum ( a[i] != b[i] for i in range(len(a)) )

def calc_pi(seqdict,nsam):
    """This is a function to calculate pi. Input arguments are the outputs of seqlist()."""
    if len(seqdict) > 1:
        for item in seqdict: ## loop through the seq dict
            thecount = seqdict[item] ## record the number of occurrences for each sequence
            theprop = float(seqdict[item])/float(nsam) ## calculate the frequency of each sequence
            seqdict[item] = theprop ## overwrite the dictionary key with the proportion
        mypi = list() ## set up an empty list to store pi values in.
        for allele in range(2,len(seqdict)+1): ## loop through the outer loop of sequences
            for allele2 in range(1,allele): ## loop through the inner loop
                differences = diff_letters(seqdict.keys()[allele-1],seqdict.keys()[allele2-1]) ## count the differences between two pairs of sequences
                length= len(seqdict.keys()[allele-1]) ## calculate the length of the sequence
                prepi = float(differences)/length ## calculate the proportion of sites where the two sequences differ
                x = seqdict[seqdict.keys()[allele-1]] ## retrieve the frequency of sequence 1
                y = seqdict[seqdict.keys()[allele2-1]] ## retrieve the frequency of sequence 2
                prepi= prepi*x*y ## get the product of the proportion of sites and the frequencies of the two sequences
                mypi.append(prepi) ## append this value to the list
        return sum(mypi) *2 *nsam/(nsam-1),length ## return pi
    else:
        length=len(seqdict.keys()[0])
        mypi = 0
        return mypi, length
def all_same(items):
    """This function checks to see if all items in a list are equal and returns a boolean."""
    return all(x == items[0] for x in items)
    
def calc_segsites(seqdict,nsam,length):
    """This is a function to calculate the number of segregating sites. It takes as input
    the output of seqdict plus the length of the sequences."""
    thecount = list() ## create an empty list
    for basepair in range(0,length): ## loop through the sites
        baselist = list() ## empty list
        for key in seqdict: ## loop through the samples
            baselist.append(key[basepair]) ## make a list of the base pairs at the site
#        print baselist
        thecount.append(all_same(baselist)) ## list of boolean results of checking if all bases at a site are the same
    return length-sum(thecount) ## return the number of sites with differences

def pop_dictionaries():
    population1 = ["pd12","pd22","pd40","pd41","pd43","pd45","pd47","P_dub_AY357611","pd48","pd5","pd54","pd55","pd56","pd57","pd59","pd61","pd63","pd65","pd67","pd68","pd71","pd74","pd75","pd76","pd77","pd78","pd50"]
    population2 = ["pd110","pd26","pd3","pd7","pd9","pd91","pd93","pd95"]
#    print population1
    nsampop1 = len(population1)
#    print population2
    nsampop2 = len(population2)
    pop1seq = {}
    pop2seq = {}
    curfile = open(filename, "r") ## open the input file, given as argument to script
    mypopdict = {}
    count = 1
    nsam = -1
    for line in curfile: ## loop through the file
        nsam +=1
        if count > 1:
            mypopdict[line.split()[0]]=line.split()[1]
        else:
            count+=1
    for key in mypopdict:
        if key in population1:
            if mypopdict[key] in pop1seq.keys():
                pop1seq[mypopdict[key]] +=1
            else:
                pop1seq[mypopdict[key]] = 1
        elif key in population2:
            if mypopdict[key] in pop2seq.keys():
                pop2seq[mypopdict[key]] += 1
            else:
                pop2seq[mypopdict[key]] = 1
        else:
            print key
    fullpop = dict(pop2seq, **pop1seq)
    return pop1seq,pop2seq,nsampop1,nsampop2

def differences_between(pop1seq,pop2seq,mynsampop1,mynsampop2):
    diff_list = list()
    counter = 0
    for allele in range(1,len(pop1seq)+1):
        for allele2 in range(1,len(pop2seq)+1):
#            print allele,allele2
            differences = diff_letters(pop1seq.keys()[allele-1],pop2seq.keys()[allele2-1])
            pop1mult = float(pop1seq[pop1seq.keys()[allele-1]])*mynsampop1
            pop2mult = float(pop2seq[pop2seq.keys()[allele2-1]])*mynsampop2
            diff_list.append(differences*pop1mult*pop2mult)
            counter += pop1mult*pop2mult
    return sum(diff_list)/counter
    

from math import log


def Hest(n):
    mylist = list()
    for i in range(1,n):
        mylist.append(float(1/float(i)))
    return sum(mylist)
#
def theta(segsites,nsam,H):
    theta = float(segsites)/float(H)
    return theta

mypop1seq,mypop2seq,mynsampop1,mynsampop2 = pop_dictionaries()
print mynsampop1, mynsampop2
myseqdict,mynsam = seqlist()
##myhaplos = counthaplotypes(myseqdict)
mypi,mylength = calc_pi(myseqdict,mynsam)
mysegsites = calc_segsites(myseqdict,mynsam,mylength)
mypop1pi,mylength1 = calc_pi(mypop1seq,mynsampop1)
mypop2pi,mylength2 = calc_pi(mypop2seq,mynsampop2)
mydifbt12 = differences_between(mypop1seq,mypop2seq,mynsampop1,mynsampop2)
myH = Hest(mynsam)
mytheta = theta(mysegsites,mynsam,myH)
##
out = open(outfile,"a")
out.write("%s\t%s\t%s\t%s\t%s\t%s\n" % (mypi,mysegsites,mypop1pi,mypop2pi,mydifbt12,mytheta))
#